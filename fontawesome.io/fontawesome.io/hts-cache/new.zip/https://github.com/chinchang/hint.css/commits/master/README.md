





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://assets-cdn.github.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/frameworks-4324702744188e5d6edc78c06517458705b8d6596db5054c244444b56c494c99.css" media="all" rel="stylesheet" />
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github-76f99dd07480164b7f348c67361a5a5cdd3797ef4f3f6ceab380ecc0ae2a2f5e.css" media="all" rel="stylesheet" />
  
  
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/site-5844159898e5c5251fccf0ea193404819fe2442dabac39f18424c78b5d7539a1.css" media="all" rel="stylesheet" />
  

  <meta name="viewport" content="width=device-width">
  
  <title>History for README.md - chinchang/hint.css · GitHub</title>
  <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta content="https://avatars2.githubusercontent.com/u/379918?v=4&amp;s=400" property="og:image" /><meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="chinchang/hint.css" property="og:title" /><meta content="https://github.com/chinchang/hint.css" property="og:url" /><meta content="hint.css - A CSS only tooltip library for your lovely websites." property="og:description" />

  <link rel="assets" href="https://assets-cdn.github.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="6228:F044:3625ED:541C1A:5971A9EB" data-pjax-transient>
  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
<meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-analytics" content="UA-3769691-2">

<meta content="collector.githubapp.com" name="octolytics-host" /><meta content="github" name="octolytics-app-id" /><meta content="https://collector.githubapp.com/github-external/browser_event" name="octolytics-event-url" /><meta content="6228:F044:3625ED:541C1A:5971A9EB" name="octolytics-dimension-request_id" /><meta content="sea" name="octolytics-dimension-region_edge" /><meta content="iad" name="octolytics-dimension-region_render" />
<meta content="/&lt;user-name&gt;/&lt;repo-name&gt;/commits/show" data-pjax-transient="true" name="analytics-location" />




  <meta class="js-ga-set" name="dimension1" content="Logged Out">


  

      <meta name="hostname" content="github.com">
  <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="NTg1NzYzMjg5NTAxZGVlZWYyODVjNzdlZjFjZTBhNGE4MGVjYmQxMzA5MGRkZjU3MjZiOWI4MGM2NzQxMTc2OXx7InJlbW90ZV9hZGRyZXNzIjoiNzQuNTAuMjEzLjgwIiwicmVxdWVzdF9pZCI6IjYyMjg6RjA0NDozNjI1RUQ6NTQxQzFBOjU5NzFBOUVCIiwidGltZXN0YW1wIjoxNTAwNjIxMjkyLCJob3N0IjoiZ2l0aHViLmNvbSJ9">


  <meta name="html-safe-nonce" content="170d70b3360b0e2e3b004c56ca74ac248bc41cff">

  <meta http-equiv="x-pjax-version" content="97722c27e681dcd9509bf112a4333d9e">
  

      <link href="https://github.com/chinchang/hint.css/commits/master.atom" rel="alternate" title="Recent Commits to hint.css:master" type="application/atom+xml">

  <meta name="description" content="hint.css - A CSS only tooltip library for your lovely websites.">
  <meta name="go-import" content="github.com/chinchang/hint.css git https://github.com/chinchang/hint.css.git">

  <meta content="379918" name="octolytics-dimension-user_id" /><meta content="chinchang" name="octolytics-dimension-user_login" /><meta content="7379964" name="octolytics-dimension-repository_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="7379964" name="octolytics-dimension-repository_network_root_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_network_root_nwo" /><meta content="false" name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



  </head>

  <body class="logged-out env-production">
    



  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    



        <div class="header header-logged-out position-relative f4 py-3" role="banner">
  <div class="container-lg px-3 clearfix">
    <div class="d-flex flex-justify-between">
      <div class="d-flex">
        <a class="header-logo-invertocat my-0" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
          <svg aria-hidden="true" class="octicon octicon-mark-github" height="32" version="1.1" viewBox="0 0 16 16" width="32"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>

        <div class="header-sitemenu clearfix">
            <nav>
              <ul class="d-flex list-style-none">
                  <li class="ml-2">
                    <a href="/features" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:features" data-selected-links="/features /features">
                      Features
</a>                  </li>
                  <li class="ml-4">
                    <a href="/business" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/security /business/customers /business">
                      Business
</a>                  </li>

                  <li class="ml-4">
                    <a href="/explore" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship /showcases /explore">
                      Explore
</a>                  </li>

                  <li class="ml-4">
                        <a href="/marketplace" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:marketplace" data-selected-links=" /marketplace">
                          Marketplace
</a>                  </li>
                  <li class="ml-4">
                    <a href="/pricing" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:pricing" data-selected-links="/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing">
                      Pricing
</a>                  </li>
              </ul>
            </nav>
        </div>
      </div>

      <div class="d-flex">
          <div class="mt-1 mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- '"` --><!-- </textarea></xmp> --></option></form><form accept-charset="UTF-8" action="/chinchang/hint.css/search" class="js-site-search-form" data-scoped-search-url="/chinchang/hint.css/search" data-unscoped-search-url="/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
    <label class="form-control header-search-wrapper js-chromeless-input-container">
        <a href="/chinchang/hint.css/commits" class="header-search-scope no-underline">This repository</a>
      <input type="text"
        class="form-control header-search-input js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s"
        name="q"
        value=""
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        autocapitalize="off">
        <input type="hidden" class="js-site-search-type-field" name="type" >
    </label>
</form></div>

          </div>

        <span class="d-inline-block">
            <div class="header-navlink px-0 py-2 m-0">
              <a class="text-bold text-white no-underline" href="/login?return_to=%2Fchinchang%2Fhint.css%2Fcommits%2Fmaster%2FREADME.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
                <span class="text-gray">or</span>
                <a class="text-bold text-white no-underline" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
            </div>
        </span>
      </div>
    </div>
  </div>
</div>


  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">
</div>



  <div role="main">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode">
    <div id="js-repo-pjax-container" data-pjax-container>
      



    <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav">
      <div class="container repohead-details-container">

        <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-eye" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/chinchang/hint.css/watchers"
     aria-label="219 users are watching this repository">
    219
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-star" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z"/></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/chinchang/hint.css/stargazers"
      aria-label="7396 users starred this repository">
      7,396
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg aria-hidden="true" class="octicon octicon-repo-forked" height="16" version="1.1" viewBox="0 0 10 16" width="10"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/chinchang/hint.css/network" class="social-count"
       aria-label="724 users forked this repository">
      724
    </a>
  </li>
</ul>

        <h1 class="public ">
  <svg aria-hidden="true" class="octicon octicon-repo" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a href="/chinchang" class="url fn" rel="author">chinchang</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a href="/chinchang/hint.css" data-pjax="#js-repo-pjax-container">hint.css</a></strong>

</h1>

      </div>
      <div class="container">
        
<nav class="reponav js-repo-nav js-sidenav-container-pjax"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css" class="js-selected-navigation-item selected reponav-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /chinchang/hint.css" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a href="/chinchang/hint.css/issues" class="js-selected-navigation-item reponav-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /chinchang/hint.css/issues" itemprop="url">
        <svg aria-hidden="true" class="octicon octicon-issue-opened" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">32</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css/pulls" class="js-selected-navigation-item reponav-item" data-hotkey="g p" data-selected-links="repo_pulls /chinchang/hint.css/pulls" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-git-pull-request" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">4</span>
      <meta itemprop="position" content="3">
</a>  </span>

    <a href="/chinchang/hint.css/projects" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /chinchang/hint.css/projects">
      <svg aria-hidden="true" class="octicon octicon-project" height="16" version="1.1" viewBox="0 0 15 16" width="15"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      Projects
      <span class="Counter" >1</span>
</a>
    <a href="/chinchang/hint.css/wiki" class="js-selected-navigation-item reponav-item" data-hotkey="g w" data-selected-links="repo_wiki /chinchang/hint.css/wiki">
      <svg aria-hidden="true" class="octicon octicon-book" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M3 5h4v1H3V5zm0 3h4V7H3v1zm0 2h4V9H3v1zm11-5h-4v1h4V5zm0 2h-4v1h4V7zm0 2h-4v1h4V9zm2-6v9c0 .55-.45 1-1 1H9.5l-1 1-1-1H2c-.55 0-1-.45-1-1V3c0-.55.45-1 1-1h5.5l1 1 1-1H15c.55 0 1 .45 1 1zm-8 .5L7.5 3H2v9h6V3.5zm7-.5H9.5l-.5.5V12h6V3z"/></svg>
      Wiki
</a>

    <div class="reponav-dropdown js-menu-container">
      <button type="button" class="btn-link reponav-item reponav-dropdown js-menu-target " data-no-toggle aria-expanded="false" aria-haspopup="true">
        Insights
        <svg aria-hidden="true" class="octicon octicon-triangle-down v-align-middle text-gray" height="11" version="1.1" viewBox="0 0 12 16" width="8"><path fill-rule="evenodd" d="M0 5l6 6 6-6z"/></svg>
      </button>
      <div class="dropdown-menu-content js-menu-content">
        <div class="dropdown-menu dropdown-menu-sw">
          <a class="dropdown-item" href="/chinchang/hint.css/pulse" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-pulse" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M11.5 8L8.8 5.4 6.6 8.5 5.5 1.6 2.38 8H0v2h3.6l.9-1.8.9 5.4L9 8.5l1.6 1.5H14V8z"/></svg>
            Pulse
          </a>
          <a class="dropdown-item" href="/chinchang/hint.css/graphs" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-graph" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
            Graphs
          </a>
        </div>
      </div>
    </div>
</nav>

      </div>
    </div>

<div class="container new-discussion-timeline experiment-repo-nav">
  <div class="repository-content">

    
    <div class="file-navigation">
      <div class="breadcrumb">
        History for <span class="repo-root js-repo-root"><span class="js-path-segment"><a href="/chinchang/hint.css/commits/master"><span>hint.css</span></a></span></span><span class="separator">/</span><strong class="final-path">README.md</strong>
      </div>
    </div>

    <div class="commits-listing commits-listing-padded js-navigation-container js-active-navigation-container" data-navigation-scroll="page">
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jun 26, 2017
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:70f111e7c437447ca1b9ed40efa9fa8f82c7ee25"
                data-url="/chinchang/hint.css/commit/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25" class="message" data-pjax="true" title="add web maker to user list">add web maker to user list</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2017-06-26T11:42:44Z">Jun 26, 2017</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="70f111e7c437447ca1b9ed40efa9fa8f82c7ee25" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    70f111e
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jun 22, 2017
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:718a64cce88a63f7dd35b960a79bece59aad3034"
                data-url="/chinchang/hint.css/commit/718a64cce88a63f7dd35b960a79bece59aad3034/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/ndduong97" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/15851465?v=4&amp;s=72" width="36" height="36" alt="@ndduong97" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/718a64cce88a63f7dd35b960a79bece59aad3034" class="message" data-pjax="true" title="Added link to &quot;who&#39;s using this&quot;">Added link to "who's using this"</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=ndduong97" aria-label="View all commits by ndduong97" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">ndduong97</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2017-06-22T22:17:32Z">Jun 22, 2017</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="718a64cce88a63f7dd35b960a79bece59aad3034" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/718a64cce88a63f7dd35b960a79bece59aad3034#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    718a64c
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/718a64cce88a63f7dd35b960a79bece59aad3034/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jan 16, 2017
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:8043580a884d1bfbc232949e83b92595741caf05"
                data-url="/chinchang/hint.css/commit/8043580a884d1bfbc232949e83b92595741caf05/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/8043580a884d1bfbc232949e83b92595741caf05" class="message" data-pjax="true" title="update user list">update user list</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2017-01-16T20:26:30Z">Jan 16, 2017</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="8043580a884d1bfbc232949e83b92595741caf05" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/8043580a884d1bfbc232949e83b92595741caf05#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    8043580
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/8043580a884d1bfbc232949e83b92595741caf05/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Nov 1, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:23f479f66afc9944aa21b48b57d17a99875d6815"
                data-url="/chinchang/hint.css/commit/23f479f66afc9944aa21b48b57d17a99875d6815/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/23f479f66afc9944aa21b48b57d17a99875d6815" class="message" data-pjax="true" title="add lesspass to user list">add lesspass to user list</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2016-11-01T20:30:18Z">Nov 1, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="23f479f66afc9944aa21b48b57d17a99875d6815" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/23f479f66afc9944aa21b48b57d17a99875d6815#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    23f479f
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/23f479f66afc9944aa21b48b57d17a99875d6815/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Sep 18, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:11461485cbf309cf5c414e57b560a542a95af906"
                data-url="/chinchang/hint.css/commit/11461485cbf309cf5c414e57b560a542a95af906/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/11461485cbf309cf5c414e57b560a542a95af906" class="message" data-pjax="true" title="Update README.md">Update README.md</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2016-09-18T10:09:55Z">Sep 18, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="11461485cbf309cf5c414e57b560a542a95af906" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/11461485cbf309cf5c414e57b560a542a95af906#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    1146148
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/11461485cbf309cf5c414e57b560a542a95af906/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Sep 17, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1"
                data-url="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1" class="message" data-pjax="true" title="update to commercial license">update to commercial license</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-09-17T07:52:18Z">Sep 17, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    af4af71
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Aug 15, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:e3150685b3a7e2e8f8a08b3a65f28189c5980dc1"
                data-url="/chinchang/hint.css/commit/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1" class="message" data-pjax="true" title="add fiverr">add fiverr</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2016-08-15T19:56:54Z">Aug 15, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="e3150685b3a7e2e8f8a08b3a65f28189c5980dc1" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    e315068
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Aug 1, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:b94fcfd5dc358df8581c9fadd3de74043f23f56c"
                data-url="/chinchang/hint.css/commit/b94fcfd5dc358df8581c9fadd3de74043f23f56c/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/b94fcfd5dc358df8581c9fadd3de74043f23f56c" class="message" data-pjax="true" title="add faq wiki link">add faq wiki link</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-08-01T18:16:50Z">Aug 1, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="b94fcfd5dc358df8581c9fadd3de74043f23f56c" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/b94fcfd5dc358df8581c9fadd3de74043f23f56c#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    b94fcfd
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/b94fcfd5dc358df8581c9fadd3de74043f23f56c/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jul 6, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:82adf5b29caebf8efe960a0e8724c961e25d4770"
                data-url="/chinchang/hint.css/commit/82adf5b29caebf8efe960a0e8724c961e25d4770/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/82adf5b29caebf8efe960a0e8724c961e25d4770" class="message" data-pjax="true" title="add tolks to users">add tolks to users</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed

                    on <strong>GitHub</strong>

                  <relative-time datetime="2016-07-06T10:30:21Z">Jul 6, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="82adf5b29caebf8efe960a0e8724c961e25d4770" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/82adf5b29caebf8efe960a0e8724c961e25d4770#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    82adf5b
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/82adf5b29caebf8efe960a0e8724c961e25d4770/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jun 5, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:00135c530a8380e2ea1101db60b45d27012d3dfa"
                data-url="/chinchang/hint.css/commit/00135c530a8380e2ea1101db60b45d27012d3dfa/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/00135c530a8380e2ea1101db60b45d27012d3dfa" class="message" data-pjax="true" title="readme: change desc.">readme: change desc.</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-06-05T09:22:08Z">Jun 5, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="00135c530a8380e2ea1101db60b45d27012d3dfa" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/00135c530a8380e2ea1101db60b45d27012d3dfa#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    00135c5
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/00135c530a8380e2ea1101db60b45d27012d3dfa/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on May 21, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:7ea96ff38cc0607f063395ac72c9b3af5e480b83"
                data-url="/chinchang/hint.css/commit/7ea96ff38cc0607f063395ac72c9b3af5e480b83/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/7ea96ff38cc0607f063395ac72c9b3af5e480b83" class="message" data-pjax="true" title="typo">typo</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-05-21T09:34:30Z">May 21, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="7ea96ff38cc0607f063395ac72c9b3af5e480b83" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/7ea96ff38cc0607f063395ac72c9b3af5e480b83#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    7ea96ff
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/7ea96ff38cc0607f063395ac72c9b3af5e480b83/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56"
                data-url="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56" class="message" data-pjax="true" title="Add docs to use aria-label attribute">Add docs to use aria-label attribute</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-05-21T09:04:01Z">May 21, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    9317acf
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 26, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:9ede1d4da020ef7e85356a4d46862db45142ac6a"
                data-url="/chinchang/hint.css/commit/9ede1d4da020ef7e85356a4d46862db45142ac6a/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/9ede1d4da020ef7e85356a4d46862db45142ac6a" class="message" data-pjax="true" title="add prototyp to user list">add prototyp to user list</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-03-26T21:06:38Z">Mar 26, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="9ede1d4da020ef7e85356a4d46862db45142ac6a" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/9ede1d4da020ef7e85356a4d46862db45142ac6a#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    9ede1d4
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/9ede1d4da020ef7e85356a4d46862db45142ac6a/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 7, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:691fd4f267e9328511f7b3a0b1bea8830e5a732d"
                data-url="/chinchang/hint.css/commit/691fd4f267e9328511f7b3a0b1bea8830e5a732d/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/691fd4f267e9328511f7b3a0b1bea8830e5a732d" class="message" data-pjax="true" title="fix readme.">fix readme.</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-03-07T21:02:03Z">Mar 7, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="691fd4f267e9328511f7b3a0b1bea8830e5a732d" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/691fd4f267e9328511f7b3a0b1bea8830e5a732d#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    691fd4f
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/691fd4f267e9328511f7b3a0b1bea8830e5a732d/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 6, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:5475046beccf7d02b646a572189e3b7c09fd02f3"
                data-url="/chinchang/hint.css/commit/5475046beccf7d02b646a572189e3b7c09fd02f3/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/5475046beccf7d02b646a572189e3b7c09fd02f3" class="message" data-pjax="true" title="add download/month badge">add download/month badge</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-03-06T10:56:43Z">Mar 6, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="5475046beccf7d02b646a572189e3b7c09fd02f3" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/5475046beccf7d02b646a572189e3b7c09fd02f3#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    5475046
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/5475046beccf7d02b646a572189e3b7c09fd02f3/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Mar 4, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:a23bed76a7bbcdab49f14288e8a476aac11f4670"
                data-url="/chinchang/hint.css/commit/a23bed76a7bbcdab49f14288e8a476aac11f4670/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/a23bed76a7bbcdab49f14288e8a476aac11f4670" class="message" data-pjax="true" title="update readme">update readme</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-03-04T19:50:46Z">Mar 4, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="a23bed76a7bbcdab49f14288e8a476aac11f4670" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/a23bed76a7bbcdab49f14288e8a476aac11f4670#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    a23bed7
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/a23bed76a7bbcdab49f14288e8a476aac11f4670/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Feb 4, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17"
                data-url="/chinchang/hint.css/commit/c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/CupOfTea696" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/7327050?v=4&amp;s=72" width="36" height="36" alt="@CupOfTea696" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17" class="message" data-pjax="true" title="camelCase variables">camelCase variables</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=CupOfTea696" aria-label="View all commits by CupOfTea696" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">CupOfTea696</a>
                  committed


                  <relative-time datetime="2016-02-04T10:38:27Z">Feb 4, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    c502cd7
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Feb 3, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:c815e638e2e086cda8a0085d3cb7eb98f0d6e325"
                data-url="/chinchang/hint.css/commit/c815e638e2e086cda8a0085d3cb7eb98f0d6e325/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/CupOfTea696" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/7327050?v=4&amp;s=72" width="36" height="36" alt="@CupOfTea696" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/c815e638e2e086cda8a0085d3cb7eb98f0d6e325" class="message" data-pjax="true" title="Add hint prefix to README">Add hint prefix to README</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=CupOfTea696" aria-label="View all commits by CupOfTea696" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">CupOfTea696</a>
                  committed


                  <relative-time datetime="2016-02-03T11:01:28Z">Feb 3, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="c815e638e2e086cda8a0085d3cb7eb98f0d6e325" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/c815e638e2e086cda8a0085d3cb7eb98f0d6e325#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    c815e63
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/c815e638e2e086cda8a0085d3cb7eb98f0d6e325/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Feb 1, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:204b2af07ba7b0bcc3d68762f784ce222b2b8a0f"
                data-url="/chinchang/hint.css/commit/204b2af07ba7b0bcc3d68762f784ce222b2b8a0f/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/204b2af07ba7b0bcc3d68762f784ce222b2b8a0f" class="message" data-pjax="true" title="add gitter badge">add gitter badge</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-02-01T18:46:29Z">Feb 1, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="204b2af07ba7b0bcc3d68762f784ce222b2b8a0f" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/204b2af07ba7b0bcc3d68762f784ce222b2b8a0f#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    204b2af
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/204b2af07ba7b0bcc3d68762f784ce222b2b8a0f/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jan 26, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:cdce53203f99d0e685c64fbab905906a60b3ba1f"
                data-url="/chinchang/hint.css/commit/cdce53203f99d0e685c64fbab905906a60b3ba1f/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/cdce53203f99d0e685c64fbab905906a60b3ba1f" class="message" data-pjax="true" title="tweak changelog section">tweak changelog section</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-01-26T18:57:05Z">Jan 26, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="cdce53203f99d0e685c64fbab905906a60b3ba1f" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/cdce53203f99d0e685c64fbab905906a60b3ba1f#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    cdce532
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/cdce53203f99d0e685c64fbab905906a60b3ba1f/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jan 25, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:00825ed7a38ed41793f57aa8590455cfa1143264"
                data-url="/chinchang/hint.css/commit/00825ed7a38ed41793f57aa8590455cfa1143264/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/00825ed7a38ed41793f57aa8590455cfa1143264" class="message" data-pjax="true" title="fix readme.">fix readme.</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-01-25T10:13:37Z">Jan 25, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="00825ed7a38ed41793f57aa8590455cfa1143264" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/00825ed7a38ed41793f57aa8590455cfa1143264#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    00825ed
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/00825ed7a38ed41793f57aa8590455cfa1143264/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jan 24, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:87301f89e74b1650cf27c8972b27f85e35514fa5"
                data-url="/chinchang/hint.css/commit/87301f89e74b1650cf27c8972b27f85e35514fa5/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/87301f89e74b1650cf27c8972b27f85e35514fa5" class="message" data-pjax="true" title="typo">typo</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-01-24T19:29:43Z">Jan 24, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="87301f89e74b1650cf27c8972b27f85e35514fa5" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/87301f89e74b1650cf27c8972b27f85e35514fa5#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    87301f8
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/87301f89e74b1650cf27c8972b27f85e35514fa5/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:a05e8dca95fbb9a3b57739d5769370803d363104"
                data-url="/chinchang/hint.css/commit/a05e8dca95fbb9a3b57739d5769370803d363104/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/a05e8dca95fbb9a3b57739d5769370803d363104" class="message" data-pjax="true" title="add more users">add more users</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-01-24T19:29:03Z">Jan 24, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="a05e8dca95fbb9a3b57739d5769370803d363104" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/a05e8dca95fbb9a3b57739d5769370803d363104#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    a05e8dc
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/a05e8dca95fbb9a3b57739d5769370803d363104/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jan 14, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:40ec930c8ff91939a7e1271e68efd1e40800bd4b"
                data-url="/chinchang/hint.css/commit/40ec930c8ff91939a7e1271e68efd1e40800bd4b/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/40ec930c8ff91939a7e1271e68efd1e40800bd4b" class="message" data-pjax="true" title="Merge pull request #104 from pra85/readmeRefine

Change sentence structure and words used">Merge pull request</a> <a href="https://github.com/chinchang/hint.css/pull/104" class="issue-link js-issue-link" data-url="https://github.com/chinchang/hint.css/issues/104" data-id="126397053" data-error-text="Failed to load issue title" data-permission-text="Issue title is private">#104</a> <a href="/chinchang/hint.css/commit/40ec930c8ff91939a7e1271e68efd1e40800bd4b" class="message" data-pjax="true" title="Merge pull request #104 from pra85/readmeRefine

Change sentence structure and words used">from pra85/readmeRefine</a>

                  <span class="hidden-text-expander inline"><button type="button" class="ellipsis-expander js-details-target" aria-expanded="false">&hellip;</button></span>
                </p>

                  <div class="commit-desc"><pre class="text-small">Change sentence structure and words used</pre></div>

                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-01-14T06:16:31Z">Jan 14, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="40ec930c8ff91939a7e1271e68efd1e40800bd4b" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/40ec930c8ff91939a7e1271e68efd1e40800bd4b#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    40ec930
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/40ec930c8ff91939a7e1271e68efd1e40800bd4b/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:2249422b7bcda30798b139d0ab43f3dbc335e7c7"
                data-url="/chinchang/hint.css/commit/2249422b7bcda30798b139d0ab43f3dbc335e7c7/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/2249422b7bcda30798b139d0ab43f3dbc335e7c7" class="message" data-pjax="true" title="Merge pull request #101 from pra85/2016

Update year to 2016">Merge pull request</a> <a href="https://github.com/chinchang/hint.css/pull/101" class="issue-link js-issue-link" data-url="https://github.com/chinchang/hint.css/issues/101" data-id="126356397" data-error-text="Failed to load issue title" data-permission-text="Issue title is private">#101</a> <a href="/chinchang/hint.css/commit/2249422b7bcda30798b139d0ab43f3dbc335e7c7" class="message" data-pjax="true" title="Merge pull request #101 from pra85/2016

Update year to 2016">from pra85/2016</a>

                  <span class="hidden-text-expander inline"><button type="button" class="ellipsis-expander js-details-target" aria-expanded="false">&hellip;</button></span>
                </p>

                  <div class="commit-desc"><pre class="text-small">Update year to 2016</pre></div>

                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2016-01-14T06:13:04Z">Jan 14, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="2249422b7bcda30798b139d0ab43f3dbc335e7c7" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/2249422b7bcda30798b139d0ab43f3dbc335e7c7#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    2249422
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/2249422b7bcda30798b139d0ab43f3dbc335e7c7/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Jan 13, 2016
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb"
                data-url="/chinchang/hint.css/commit/ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/pra85" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=72" width="36" height="36" alt="@pra85" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb" class="message" data-pjax="true" title="docs(readme): change sentence structure and words used">docs(readme): change sentence structure and words used</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=pra85" aria-label="View all commits by pra85" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">pra85</a>
                  committed


                  <relative-time datetime="2016-01-13T11:17:45Z">Jan 13, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    ac2b414
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a"
                data-url="/chinchang/hint.css/commit/9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/pra85" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=72" width="36" height="36" alt="@pra85" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a" class="message" data-pjax="true" title="docs(readme): add link to cdnjs hosted version">docs(readme): add link to cdnjs hosted version</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=pra85" aria-label="View all commits by pra85" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">pra85</a>
                  committed


                  <relative-time datetime="2016-01-13T10:20:22Z">Jan 13, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    9e4203e
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:c814923f780512698ed4f9150d36b1172c6b2825"
                data-url="/chinchang/hint.css/commit/c814923f780512698ed4f9150d36b1172c6b2825/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/pra85" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=72" width="36" height="36" alt="@pra85" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/c814923f780512698ed4f9150d36b1172c6b2825" class="message" data-pjax="true" title="chore(app): update year to 2016">chore(app): update year to 2016</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=pra85" aria-label="View all commits by pra85" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">pra85</a>
                  committed


                  <relative-time datetime="2016-01-13T06:56:03Z">Jan 13, 2016</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="c814923f780512698ed4f9150d36b1172c6b2825" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/c814923f780512698ed4f9150d36b1172c6b2825#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    c814923
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/c814923f780512698ed4f9150d36b1172c6b2825/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Dec 29, 2015
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:d960fb98005881604436192d4dc63f70cde0ff65"
                data-url="/chinchang/hint.css/commit/d960fb98005881604436192d4dc63f70cde0ff65/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/d960fb98005881604436192d4dc63f70cde0ff65" class="message" data-pjax="true" title="add usepanda.com to user list">add usepanda.com to user list</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2015-12-29T06:14:00Z">Dec 29, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="d960fb98005881604436192d4dc63f70cde0ff65" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/d960fb98005881604436192d4dc63f70cde0ff65#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    d960fb9
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/d960fb98005881604436192d4dc63f70cde0ff65/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Dec 28, 2015
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:a289af46e9d4cdb42f283fb1853e815cf2231b6f"
                data-url="/chinchang/hint.css/commit/a289af46e9d4cdb42f283fb1853e815cf2231b6f/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/a289af46e9d4cdb42f283fb1853e815cf2231b6f" class="message" data-pjax="true" title="add version badge">add version badge</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2015-12-28T21:04:04Z">Dec 28, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="a289af46e9d4cdb42f283fb1853e815cf2231b6f" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/a289af46e9d4cdb42f283fb1853e815cf2231b6f#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    a289af4
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/a289af46e9d4cdb42f283fb1853e815cf2231b6f/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:332fb80b6f35ed2589dec1fbe77621feaeef44bc"
                data-url="/chinchang/hint.css/commit/332fb80b6f35ed2589dec1fbe77621feaeef44bc/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/332fb80b6f35ed2589dec1fbe77621feaeef44bc" class="message" data-pjax="true" title="Add codemagic to user list

codeMagic is a tool by @varemenos">Add codemagic to user list</a>

                  <span class="hidden-text-expander inline"><button type="button" class="ellipsis-expander js-details-target" aria-expanded="false">&hellip;</button></span>
                </p>

                  <div class="commit-desc"><pre class="text-small">codeMagic is a tool by <a href="https://github.com/varemenos" class="user-mention">@varemenos</a></pre></div>

                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2015-12-28T21:00:16Z">Dec 28, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="332fb80b6f35ed2589dec1fbe77621feaeef44bc" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/332fb80b6f35ed2589dec1fbe77621feaeef44bc#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    332fb80
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/332fb80b6f35ed2589dec1fbe77621feaeef44bc/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Dec 3, 2015
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:c320243611b8280369f3b0b5f2ab12bf0836cce4"
                data-url="/chinchang/hint.css/commit/c320243611b8280369f3b0b5f2ab12bf0836cce4/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/c320243611b8280369f3b0b5f2ab12bf0836cce4" class="message" data-pjax="true" title="fix webflow name in user list">fix webflow name in user list</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2015-12-03T18:14:44Z">Dec 3, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="c320243611b8280369f3b0b5f2ab12bf0836cce4" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/c320243611b8280369f3b0b5f2ab12bf0836cce4#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    c320243
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/c320243611b8280369f3b0b5f2ab12bf0836cce4/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:a40dd93f292a2dbf54f42bb2a3527e62a16ec8aa"
                data-url="/chinchang/hint.css/commit/a40dd93f292a2dbf54f42bb2a3527e62a16ec8aa/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/chinchang" data-skip-pjax="true" rel="author">
                      <img src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=72" width="36" height="36" alt="@chinchang" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/a40dd93f292a2dbf54f42bb2a3527e62a16ec8aa" class="message" data-pjax="true" title="add fiverrs devflow to user list.">add fiverrs devflow to user list.</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=chinchang" aria-label="View all commits by chinchang" class="commit-author tooltipped tooltipped-s user-mention" rel="author">chinchang</a>
                  committed


                  <relative-time datetime="2015-12-03T18:11:00Z">Dec 3, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="a40dd93f292a2dbf54f42bb2a3527e62a16ec8aa" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/a40dd93f292a2dbf54f42bb2a3527e62a16ec8aa#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    a40dd93
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/a40dd93f292a2dbf54f42bb2a3527e62a16ec8aa/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Nov 24, 2015
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:d61ea3730c492de9f31492c9ceb8891ca3deedf2"
                data-url="/chinchang/hint.css/commit/d61ea3730c492de9f31492c9ceb8891ca3deedf2/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/basarat" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars1.githubusercontent.com/u/874898?v=4&amp;s=72" width="36" height="36" alt="@basarat" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/d61ea3730c492de9f31492c9ceb8891ca3deedf2" class="message" data-pjax="true" title=":memo: add TypeScript Builder in the list of friends"><g-emoji alias="memo" fallback-src="https://assets-cdn.github.com/images/icons/emoji/unicode/1f4dd.png" ios-version="6.0">📝</g-emoji> add TypeScript Builder in the list of friends</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=basarat" aria-label="View all commits by basarat" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">basarat</a>
                  committed


                  <relative-time datetime="2015-11-24T07:21:48Z">Nov 24, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="d61ea3730c492de9f31492c9ceb8891ca3deedf2" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/d61ea3730c492de9f31492c9ceb8891ca3deedf2#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    d61ea37
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/d61ea3730c492de9f31492c9ceb8891ca3deedf2/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
        <div class="commit-group-title">
          <svg aria-hidden="true" class="octicon octicon-git-commit" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M10.86 7c-.45-1.72-2-3-3.86-3-1.86 0-3.41 1.28-3.86 3H0v2h3.14c.45 1.72 2 3 3.86 3 1.86 0 3.41-1.28 3.86-3H14V7h-3.14zM7 10.2c-1.22 0-2.2-.98-2.2-2.2 0-1.22.98-2.2 2.2-2.2 1.22 0 2.2.98 2.2 2.2 0 1.22-.98 2.2-2.2 2.2z"/></svg>Commits on Nov 20, 2015
        </div>

        <ol class="commit-group table-list table-list-bordered">
            <li class="commit commits-list-item table-list-item js-navigation-item js-details-container Details js-socket-channel js-updatable-content"
                data-channel="repo:7379964:commit:f19600edce2955868ad19b0fefb44eada2229ccd"
                data-url="/chinchang/hint.css/commit/f19600edce2955868ad19b0fefb44eada2229ccd/show_partial?partial=commits%2Fcommits_list_item">

              <div class="table-list-cell commit-avatar-cell">
                <div class="avatar-parent-child">
                    <a href="/EvanHahn" data-skip-pjax="true" rel="contributor">
                      <img src="https://avatars3.githubusercontent.com/u/777712?v=4&amp;s=72" width="36" height="36" alt="@EvanHahn" class="avatar">
                    </a>
                </div>
              </div>
              <div class="table-list-cell">
                <p class="commit-title ">
                    <a href="/chinchang/hint.css/commit/f19600edce2955868ad19b0fefb44eada2229ccd" class="message" data-pjax="true" title="The H in GitHub should be capitalized">The H in GitHub should be capitalized</a>

                  
                </p>


                <div class="commit-meta commit-author-section">
                    <a href="/chinchang/hint.css/commits/master/README.md?author=EvanHahn" aria-label="View all commits by EvanHahn" class="commit-author tooltipped tooltipped-s user-mention" rel="contributor">EvanHahn</a>
                  committed


                  <relative-time datetime="2015-11-20T23:48:47Z">Nov 20, 2015</relative-time>

                </div>

              </div>
              <div class="commit-links-cell table-list-cell">

                


                <div class="commit-links-group BtnGroup">
                  <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline BtnGroup-item zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="f19600edce2955868ad19b0fefb44eada2229ccd" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
                  <a href="/chinchang/hint.css/commit/f19600edce2955868ad19b0fefb44eada2229ccd#diff-04c6e90faac2675aa89e2176d2eec7d8" class="sha btn btn-outline BtnGroup-item">
                    f19600e
                  </a>
                </div>
                <a href="/chinchang/hint.css/tree/f19600edce2955868ad19b0fefb44eada2229ccd/README.md" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-sw" rel="nofollow"><svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg></a>
              </div>
            </li>
        </ol>
    </div>

    <div class="paginate-container" data-pjax data-html-cleaner-suppress-children>
      <div class="pagination"><span class="disabled">Newer</span><a href="https://github.com/chinchang/hint.css/commits/master?after=70f111e7c437447ca1b9ed40efa9fa8f82c7ee25+34&amp;path%5B%5D=README.md" rel="nofollow">Older</a></div>
    </div>

  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

      
<div class="container-lg site-footer-container">
  <div class="site-footer " role="contentinfo">
    <ul class="site-footer-links float-right">
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact GitHub</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage" class="site-footer-mark" title="GitHub">
      <svg aria-hidden="true" class="octicon octicon-mark-github" height="24" version="1.1" viewBox="0 0 16 16" width="24"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2017 <span title="0.29820s from unicorn-1253541411-fhpkr">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a href="https://help.github.com" data-ga-click="Footer, go to help, text:help">Help</a></li>
    </ul>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <button type="button" class="flash-close js-flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
    You can't perform that action at this time.
  </div>


    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/compat-91f98c37fc84eac24836eec2567e9912742094369a04c4eba6e3cd1fa18902d9.js"></script>
    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-fb7732750125d3d783cd735f5f1ecddc0fab988ecd5bd8ce63c326337b7c4de6.js"></script>
    
    <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github-da8e77af323b7cf0c46c7ce4e7a65719fb641271a5d4d8cc9010b77f135085d5.js"></script>
    
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
  </div>
</div>


  </body>
</html>

