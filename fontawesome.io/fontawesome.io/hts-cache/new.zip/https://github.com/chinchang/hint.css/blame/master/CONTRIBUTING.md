





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://assets-cdn.github.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/frameworks-4324702744188e5d6edc78c06517458705b8d6596db5054c244444b56c494c99.css" media="all" rel="stylesheet" />
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github-76f99dd07480164b7f348c67361a5a5cdd3797ef4f3f6ceab380ecc0ae2a2f5e.css" media="all" rel="stylesheet" />
  
  
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/site-5844159898e5c5251fccf0ea193404819fe2442dabac39f18424c78b5d7539a1.css" media="all" rel="stylesheet" />
  

  <meta name="viewport" content="width=device-width">
  
  <title>hint.css/CONTRIBUTING.md at master · chinchang/hint.css · GitHub</title>
  <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta content="https://avatars2.githubusercontent.com/u/379918?v=4&amp;s=400" property="og:image" /><meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="chinchang/hint.css" property="og:title" /><meta content="https://github.com/chinchang/hint.css" property="og:url" /><meta content="hint.css - A CSS only tooltip library for your lovely websites." property="og:description" />

  <link rel="assets" href="https://assets-cdn.github.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="6237:F043:1CDB04:2CD340:5971A92F" data-pjax-transient>
  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
<meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-analytics" content="UA-3769691-2">

<meta content="collector.githubapp.com" name="octolytics-host" /><meta content="github" name="octolytics-app-id" /><meta content="https://collector.githubapp.com/github-external/browser_event" name="octolytics-event-url" /><meta content="6237:F043:1CDB04:2CD340:5971A92F" name="octolytics-dimension-request_id" /><meta content="sea" name="octolytics-dimension-region_edge" /><meta content="iad" name="octolytics-dimension-region_render" />
<meta content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame" data-pjax-transient="true" name="analytics-location" />




  <meta class="js-ga-set" name="dimension1" content="Logged Out">


  

      <meta name="hostname" content="github.com">
  <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="YjMwMjdlZTg4ZGZjMDQ0ODNjYmY1N2FiNTE4OGUxZjcwNTlhYmEwZTg3ZGYyMDQ5YzRiMjg0YzhkZTM2YzZmMHx7InJlbW90ZV9hZGRyZXNzIjoiNzQuNTAuMjEzLjgwIiwicmVxdWVzdF9pZCI6IjYyMzc6RjA0MzoxQ0RCMDQ6MkNEMzQwOjU5NzFBOTJGIiwidGltZXN0YW1wIjoxNTAwNjIxMTA0LCJob3N0IjoiZ2l0aHViLmNvbSJ9">


  <meta name="html-safe-nonce" content="170d70b3360b0e2e3b004c56ca74ac248bc41cff">

  <meta http-equiv="x-pjax-version" content="97722c27e681dcd9509bf112a4333d9e">
  

      <link href="https://github.com/chinchang/hint.css/commits/master.atom" rel="alternate" title="Recent Commits to hint.css:master" type="application/atom+xml">

  <meta name="description" content="hint.css - A CSS only tooltip library for your lovely websites.">
  <meta name="go-import" content="github.com/chinchang/hint.css git https://github.com/chinchang/hint.css.git">

  <meta content="379918" name="octolytics-dimension-user_id" /><meta content="chinchang" name="octolytics-dimension-user_login" /><meta content="7379964" name="octolytics-dimension-repository_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="7379964" name="octolytics-dimension-repository_network_root_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_network_root_nwo" /><meta content="false" name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



  </head>

  <body class="logged-out env-production full-width">
    



  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    



        <div class="header header-logged-out position-relative f4 py-3" role="banner">
  <div class="container-lg px-3 clearfix">
    <div class="d-flex flex-justify-between">
      <div class="d-flex">
        <a class="header-logo-invertocat my-0" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
          <svg aria-hidden="true" class="octicon octicon-mark-github" height="32" version="1.1" viewBox="0 0 16 16" width="32"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>

        <div class="header-sitemenu clearfix">
            <nav>
              <ul class="d-flex list-style-none">
                  <li class="ml-2">
                    <a href="/features" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:features" data-selected-links="/features /features">
                      Features
</a>                  </li>
                  <li class="ml-4">
                    <a href="/business" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/security /business/customers /business">
                      Business
</a>                  </li>

                  <li class="ml-4">
                    <a href="/explore" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship /showcases /explore">
                      Explore
</a>                  </li>

                  <li class="ml-4">
                        <a href="/marketplace" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:marketplace" data-selected-links=" /marketplace">
                          Marketplace
</a>                  </li>
                  <li class="ml-4">
                    <a href="/pricing" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:pricing" data-selected-links="/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing">
                      Pricing
</a>                  </li>
              </ul>
            </nav>
        </div>
      </div>

      <div class="d-flex">
          <div class="mt-1 mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- '"` --><!-- </textarea></xmp> --></option></form><form accept-charset="UTF-8" action="/chinchang/hint.css/search" class="js-site-search-form" data-scoped-search-url="/chinchang/hint.css/search" data-unscoped-search-url="/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
    <label class="form-control header-search-wrapper js-chromeless-input-container">
        <a href="/chinchang/hint.css/blame/master/CONTRIBUTING.md" class="header-search-scope no-underline">This repository</a>
      <input type="text"
        class="form-control header-search-input js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s"
        name="q"
        value=""
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        autocapitalize="off">
        <input type="hidden" class="js-site-search-type-field" name="type" >
    </label>
</form></div>

          </div>

        <span class="d-inline-block">
            <div class="header-navlink px-0 py-2 m-0">
              <a class="text-bold text-white no-underline" href="/login?return_to=%2Fchinchang%2Fhint.css%2Fblame%2Fmaster%2FCONTRIBUTING.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
                <span class="text-gray">or</span>
                <a class="text-bold text-white no-underline" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
            </div>
        </span>
      </div>
    </div>
  </div>
</div>


  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">
</div>



  <div role="main">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode">
    <div id="js-repo-pjax-container" data-pjax-container>
      



    <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav">
      <div class="container repohead-details-container">

        <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-eye" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/chinchang/hint.css/watchers"
     aria-label="219 users are watching this repository">
    219
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-star" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z"/></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/chinchang/hint.css/stargazers"
      aria-label="7396 users starred this repository">
      7,396
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg aria-hidden="true" class="octicon octicon-repo-forked" height="16" version="1.1" viewBox="0 0 10 16" width="10"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/chinchang/hint.css/network" class="social-count"
       aria-label="724 users forked this repository">
      724
    </a>
  </li>
</ul>

        <h1 class="public ">
  <svg aria-hidden="true" class="octicon octicon-repo" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a href="/chinchang" class="url fn" rel="author">chinchang</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a href="/chinchang/hint.css" data-pjax="#js-repo-pjax-container">hint.css</a></strong>

</h1>

      </div>
      <div class="container">
        
<nav class="reponav js-repo-nav js-sidenav-container-pjax"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css" class="js-selected-navigation-item selected reponav-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /chinchang/hint.css" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a href="/chinchang/hint.css/issues" class="js-selected-navigation-item reponav-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /chinchang/hint.css/issues" itemprop="url">
        <svg aria-hidden="true" class="octicon octicon-issue-opened" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">32</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css/pulls" class="js-selected-navigation-item reponav-item" data-hotkey="g p" data-selected-links="repo_pulls /chinchang/hint.css/pulls" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-git-pull-request" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">4</span>
      <meta itemprop="position" content="3">
</a>  </span>

    <a href="/chinchang/hint.css/projects" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /chinchang/hint.css/projects">
      <svg aria-hidden="true" class="octicon octicon-project" height="16" version="1.1" viewBox="0 0 15 16" width="15"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      Projects
      <span class="Counter" >1</span>
</a>
    <a href="/chinchang/hint.css/wiki" class="js-selected-navigation-item reponav-item" data-hotkey="g w" data-selected-links="repo_wiki /chinchang/hint.css/wiki">
      <svg aria-hidden="true" class="octicon octicon-book" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M3 5h4v1H3V5zm0 3h4V7H3v1zm0 2h4V9H3v1zm11-5h-4v1h4V5zm0 2h-4v1h4V7zm0 2h-4v1h4V9zm2-6v9c0 .55-.45 1-1 1H9.5l-1 1-1-1H2c-.55 0-1-.45-1-1V3c0-.55.45-1 1-1h5.5l1 1 1-1H15c.55 0 1 .45 1 1zm-8 .5L7.5 3H2v9h6V3.5zm7-.5H9.5l-.5.5V12h6V3z"/></svg>
      Wiki
</a>

    <div class="reponav-dropdown js-menu-container">
      <button type="button" class="btn-link reponav-item reponav-dropdown js-menu-target " data-no-toggle aria-expanded="false" aria-haspopup="true">
        Insights
        <svg aria-hidden="true" class="octicon octicon-triangle-down v-align-middle text-gray" height="11" version="1.1" viewBox="0 0 12 16" width="8"><path fill-rule="evenodd" d="M0 5l6 6 6-6z"/></svg>
      </button>
      <div class="dropdown-menu-content js-menu-content">
        <div class="dropdown-menu dropdown-menu-sw">
          <a class="dropdown-item" href="/chinchang/hint.css/pulse" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-pulse" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M11.5 8L8.8 5.4 6.6 8.5 5.5 1.6 2.38 8H0v2h3.6l.9-1.8.9 5.4L9 8.5l1.6 1.5H14V8z"/></svg>
            Pulse
          </a>
          <a class="dropdown-item" href="/chinchang/hint.css/graphs" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-graph" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
            Graphs
          </a>
        </div>
      </div>
    </div>
</nav>

      </div>
    </div>

<div class="container new-discussion-timeline experiment-repo-nav">
  <div class="repository-content">

    

  <div class="wants-full-width-container"></div>

  <a href="/chinchang/hint.css/blame/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25/CONTRIBUTING.md" class="d-none js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
    <span class="css-truncate-target js-zeroclipboard-target"><span class="repo-root js-repo-root"><span class="js-path-segment"><a href="/chinchang/hint.css"><span>hint.css</span></a></span></span><span class="separator">/</span><strong class="final-path">CONTRIBUTING.md</strong></span>
    <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
  </div>

  <div class="line-age-legend">
    <span>Newer</span>
    <ol>
        <li class="heat" data-heat="1"></li>
        <li class="heat" data-heat="2"></li>
        <li class="heat" data-heat="3"></li>
        <li class="heat" data-heat="4"></li>
        <li class="heat" data-heat="5"></li>
        <li class="heat" data-heat="6"></li>
        <li class="heat" data-heat="7"></li>
        <li class="heat" data-heat="8"></li>
        <li class="heat" data-heat="9"></li>
        <li class="heat" data-heat="10"></li>
    </ol>
    <span>Older</span>
  </div>

  <div class="file">
    <div class="file-header">
      <div class="file-actions">
        <div class="BtnGroup">
          <a href="/chinchang/hint.css/raw/master/CONTRIBUTING.md" class="btn btn-sm BtnGroup-item" id="raw-url">Raw</a>
          <a href="/chinchang/hint.css/blob/master/CONTRIBUTING.md" class="btn btn-sm js-update-url-with-hash BtnGroup-item">Normal view</a>
          <a href="/chinchang/hint.css/commits/master/CONTRIBUTING.md" class="btn btn-sm BtnGroup-item" rel="nofollow">History</a>
        </div>
      </div>

  

      <div class="file-info">
        <svg aria-hidden="true" class="octicon octicon-file-text" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"/></svg>
        <span class="file-mode" title="File Mode">100644</span>
        <span class="file-info-divider"></span>
          41 lines (22 sloc)
          <span class="file-info-divider"></span>
        1.85 KB
      </div>
    </div>

    <div class="blob-wrapper">
      <table class="blame-container highlight data js-file-line-container tab-size" data-tab-size="8">
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-mb">**Hint**</span> is written in [<span class="pl-e">SASS</span>](http://sass-lang.com/).</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC2"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-mh"><span class="pl-mh">#</span>Setup</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-v">1.</span> [<span class="pl-e">Fork **Hint.css**</span>](https://help.github.com/articles/fork-a-repo) and clone it on your system.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:22:27Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/3a922501f91b7df6cc877c15aa18d619e701d8f2" class="message" data-pjax="true" title="add contributing link in README and make correction in Contributing">add contributing link in README and make correction in Contributing</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/325a714c2a22cc9fcba77d0c3f3652eeef861d07/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-v">2.</span> Create a new branch out off <span class="pl-c1">`master`</span> for your fix/feature. <span class="pl-c1">`git checkout new-feature master`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC6"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-mh"><span class="pl-mh">#</span>Building</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC8"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-mb">**Hint.css**</span> uses [<span class="pl-e">Grunt</span>](http://gruntjs.com/) for the build process which you need to have installed on your system.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC10"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-13T14:16:09Z">Jan 13, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/208633a019d36ba0c95482bb3bca994c4633cf9e" class="message" data-pjax="true" title="refactor(contributing): add reference of other grunt plugin used">refactor(contributing): add reference of other grunt plugin used</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/f446c9781c5a74a0d59b46ac2eff214a9f68fb9e/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC11">Also there are four additional Grunt tasks required to build the library:</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC12"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-13T13:33:26Z">Jan 13, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/4e00b39ce5032322047865bc57d8265d39fe3e5d" class="message" data-pjax="true" title="refactor(contributing): renamed grunt-contrib-mincss to grunt-contrib-cssmin">refactor(contributing): renamed grunt-contrib-mincss to grunt-contrib…</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/d960fb98005881604436192d4dc63f70cde0ff65/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-v">1.</span> [<span class="pl-e">grunt-contrib-cssmin</span>](https://npmjs.org/package/grunt-contrib-cssmin)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC14"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-28T07:38:26Z">Jan 28, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/fc9f6cfe7d6ccf4992d0af495e10115abdf9e4bf" class="message" data-pjax="true" title="Update reference to Node SASS plugin">Update reference to Node SASS plugin</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/cdce53203f99d0e685c64fbab905906a60b3ba1f/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC15"><span class="pl-v">2.</span> [<span class="pl-e">grunt-sass</span>](https://www.npmjs.com/package/grunt-sass)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC16"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="5">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-13T14:16:09Z">Jan 13, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/208633a019d36ba0c95482bb3bca994c4633cf9e" class="message" data-pjax="true" title="refactor(contributing): add reference of other grunt plugin used">refactor(contributing): add reference of other grunt plugin used</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="5">
                  <a href="/chinchang/hint.css/blame/f446c9781c5a74a0d59b46ac2eff214a9f68fb9e/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC17"><span class="pl-v">3.</span> [<span class="pl-e">grunt-contrib-concat</span>](https://www.npmjs.com/package/grunt-contrib-concat)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC18"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC19"><span class="pl-v">4.</span> [<span class="pl-e">grunt-contrib-watch</span>](https://www.npmjs.com/package/grunt-contrib-watch)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC20"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC21">To install all the dependencies, run <span class="pl-c1">`npm install`</span>.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC22"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC23">Once you have the dependencies installed, run <span class="pl-c1">`grunt`</span> from the project directory. This will run the default grunt task which compiles the SCSS files into <span class="pl-c1">`hint.css`</span> file.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC24"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-03T18:57:57Z">Mar 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/e50d7ba7abb862f3e4b51981061f168ea9fd3298" class="message" data-pjax="true" title="add comment on how to generate minified lib using grunt">add comment on how to generate minified lib using grunt</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/aa3de272c858ed3cfdc0c429e32757ebd5c1f8ed/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC25">Though this should be sufficient for building the library for testing, in case you want to build the minified version as well you can run the <span class="pl-c1">`grunt deploy`</span> command instead.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC26"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:00:48Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/325a714c2a22cc9fcba77d0c3f3652eeef861d07" class="message" data-pjax="true" title="add further points">add further points</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC27"><span class="pl-mh"><span class="pl-mh">#</span>Things to remember</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC28"><span class="pl-v">-</span> Do not fix multiple issues in a single commit. Keep them one thing per commit so that they can be picked easily incase only few commits require to be merged.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T14:25:03Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7585c2eb1ca289bdddb864a2c76a1a8ab6d771f3" class="message" data-pjax="true" title="add CONTRIBUTING file to project">add CONTRIBUTING file to project</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC29"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:22:27Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/3a922501f91b7df6cc877c15aa18d619e701d8f2" class="message" data-pjax="true" title="add contributing link in README and make correction in Contributing">add contributing link in README and make correction in Contributing</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/325a714c2a22cc9fcba77d0c3f3652eeef861d07/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC30"><span class="pl-v">-</span> For every new modifier (example <span class="pl-c1">`hint--success`</span>, <span class="pl-c1">`hint--top`</span>) added, make a separate file unless it fits into a current modifier file.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC31"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-02T23:46:24Z">Mar 2, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/aa3de272c858ed3cfdc0c429e32757ebd5c1f8ed" class="message" data-pjax="true" title="add one more point to remember">add one more point to remember</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/f9cbb00c7e0add42667672c1e3c7ec59e284e41b/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC32"><span class="pl-v">-</span> Before submitting a patch, rebase your branch on upstream <span class="pl-c1">`master`</span> to make life easier for the merger.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC33"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="7">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-03T19:49:10Z">Mar 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/2cbaf5b23bf226e36129e2dd521b1e672fe6b498" class="message" data-pjax="true" title="v1.2.0 [Hotfix] add mailing list address">v1.2.0 [Hotfix] add mailing list address</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="7">
                  <a href="/chinchang/hint.css/blame/453611b2ae04974530f4dc95cb6a50d970f33331/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC34"><span class="pl-v">-</span> <span class="pl-mb">**DO NOT**</span> add the library builds (<span class="pl-c1">`hint.css`</span> &amp; <span class="pl-c1">`hint.min.css`</span>) in your commits.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC35"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC36"><span class="pl-mh"><span class="pl-mh">#</span>Stay in touch</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC37"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC38">To catch all updates and discussion, join the mailing list: <span class="pl-mb">**hintcss@googlegroups.com**</span>.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC39"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-13T13:33:26Z">Jan 13, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/4e00b39ce5032322047865bc57d8265d39fe3e5d" class="message" data-pjax="true" title="refactor(contributing): renamed grunt-contrib-mincss to grunt-contrib-cssmin">refactor(contributing): renamed grunt-contrib-mincss to grunt-contrib…</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/d960fb98005881604436192d4dc63f70cde0ff65/CONTRIBUTING.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC40">To subscribe: <span class="pl-mb">**hintcss+subscribe@googlegroups.com**</span> or visit [<span class="pl-e">here</span>](https://groups.google.com/forum/?fromgroups=#!forum/hintcss).</td>
              </tr>
          </tbody>
      </table>
    </div>

  </div>


  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

      
<div class="container-lg site-footer-container">
  <div class="site-footer " role="contentinfo">
    <ul class="site-footer-links float-right">
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact GitHub</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage" class="site-footer-mark" title="GitHub">
      <svg aria-hidden="true" class="octicon octicon-mark-github" height="24" version="1.1" viewBox="0 0 16 16" width="24"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2017 <span title="0.15177s from unicorn-1253541411-j52bb">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a href="https://help.github.com" data-ga-click="Footer, go to help, text:help">Help</a></li>
    </ul>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <button type="button" class="flash-close js-flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
    You can't perform that action at this time.
  </div>


    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/compat-91f98c37fc84eac24836eec2567e9912742094369a04c4eba6e3cd1fa18902d9.js"></script>
    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-fb7732750125d3d783cd735f5f1ecddc0fab988ecd5bd8ce63c326337b7c4de6.js"></script>
    
    <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github-da8e77af323b7cf0c46c7ce4e7a65719fb641271a5d4d8cc9010b77f135085d5.js"></script>
    
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
  </div>
</div>


  </body>
</html>

