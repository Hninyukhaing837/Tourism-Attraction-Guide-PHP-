





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://assets-cdn.github.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/frameworks-4324702744188e5d6edc78c06517458705b8d6596db5054c244444b56c494c99.css" media="all" rel="stylesheet" />
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github-76f99dd07480164b7f348c67361a5a5cdd3797ef4f3f6ceab380ecc0ae2a2f5e.css" media="all" rel="stylesheet" />
  
  
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/site-5844159898e5c5251fccf0ea193404819fe2442dabac39f18424c78b5d7539a1.css" media="all" rel="stylesheet" />
  

  <meta name="viewport" content="width=device-width">
  
  <title>hint.css/LICENSE.md at master · chinchang/hint.css · GitHub</title>
  <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta content="https://avatars2.githubusercontent.com/u/379918?v=4&amp;s=400" property="og:image" /><meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="chinchang/hint.css" property="og:title" /><meta content="https://github.com/chinchang/hint.css" property="og:url" /><meta content="hint.css - A CSS only tooltip library for your lovely websites." property="og:description" />

  <link rel="assets" href="https://assets-cdn.github.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="623A:F044:330A13:4F4282:5971A2F5" data-pjax-transient>
  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
<meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-analytics" content="UA-3769691-2">

<meta content="collector.githubapp.com" name="octolytics-host" /><meta content="github" name="octolytics-app-id" /><meta content="https://collector.githubapp.com/github-external/browser_event" name="octolytics-event-url" /><meta content="623A:F044:330A13:4F4282:5971A2F5" name="octolytics-dimension-request_id" /><meta content="sea" name="octolytics-dimension-region_edge" /><meta content="iad" name="octolytics-dimension-region_render" />
<meta content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame" data-pjax-transient="true" name="analytics-location" />




  <meta class="js-ga-set" name="dimension1" content="Logged Out">


  

      <meta name="hostname" content="github.com">
  <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="MDAxZGZmZjVkN2E3YzE4NTA3NTJjZGM3NmEyNzAxZGJkMjk4NGE3YjQyYTI2NzVmMjMwMjFkMDRlMDZkNGNhMXx7InJlbW90ZV9hZGRyZXNzIjoiNzQuNTAuMjEzLjgwIiwicmVxdWVzdF9pZCI6IjYyM0E6RjA0NDozMzBBMTM6NEY0MjgyOjU5NzFBMkY1IiwidGltZXN0YW1wIjoxNTAwNjE5NTEwLCJob3N0IjoiZ2l0aHViLmNvbSJ9">


  <meta name="html-safe-nonce" content="170d70b3360b0e2e3b004c56ca74ac248bc41cff">

  <meta http-equiv="x-pjax-version" content="97722c27e681dcd9509bf112a4333d9e">
  

      <link href="https://github.com/chinchang/hint.css/commits/master.atom" rel="alternate" title="Recent Commits to hint.css:master" type="application/atom+xml">

  <meta name="description" content="hint.css - A CSS only tooltip library for your lovely websites.">
  <meta name="go-import" content="github.com/chinchang/hint.css git https://github.com/chinchang/hint.css.git">

  <meta content="379918" name="octolytics-dimension-user_id" /><meta content="chinchang" name="octolytics-dimension-user_login" /><meta content="7379964" name="octolytics-dimension-repository_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="7379964" name="octolytics-dimension-repository_network_root_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_network_root_nwo" /><meta content="false" name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



  </head>

  <body class="logged-out env-production full-width">
    



  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    



        <div class="header header-logged-out position-relative f4 py-3" role="banner">
  <div class="container-lg px-3 clearfix">
    <div class="d-flex flex-justify-between">
      <div class="d-flex">
        <a class="header-logo-invertocat my-0" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
          <svg aria-hidden="true" class="octicon octicon-mark-github" height="32" version="1.1" viewBox="0 0 16 16" width="32"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>

        <div class="header-sitemenu clearfix">
            <nav>
              <ul class="d-flex list-style-none">
                  <li class="ml-2">
                    <a href="/features" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:features" data-selected-links="/features /features">
                      Features
</a>                  </li>
                  <li class="ml-4">
                    <a href="/business" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/security /business/customers /business">
                      Business
</a>                  </li>

                  <li class="ml-4">
                    <a href="/explore" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship /showcases /explore">
                      Explore
</a>                  </li>

                  <li class="ml-4">
                        <a href="/marketplace" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:marketplace" data-selected-links=" /marketplace">
                          Marketplace
</a>                  </li>
                  <li class="ml-4">
                    <a href="/pricing" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:pricing" data-selected-links="/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing">
                      Pricing
</a>                  </li>
              </ul>
            </nav>
        </div>
      </div>

      <div class="d-flex">
          <div class="mt-1 mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- '"` --><!-- </textarea></xmp> --></option></form><form accept-charset="UTF-8" action="/chinchang/hint.css/search" class="js-site-search-form" data-scoped-search-url="/chinchang/hint.css/search" data-unscoped-search-url="/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
    <label class="form-control header-search-wrapper js-chromeless-input-container">
        <a href="/chinchang/hint.css/blame/master/LICENSE.md" class="header-search-scope no-underline">This repository</a>
      <input type="text"
        class="form-control header-search-input js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s"
        name="q"
        value=""
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        autocapitalize="off">
        <input type="hidden" class="js-site-search-type-field" name="type" >
    </label>
</form></div>

          </div>

        <span class="d-inline-block">
            <div class="header-navlink px-0 py-2 m-0">
              <a class="text-bold text-white no-underline" href="/login?return_to=%2Fchinchang%2Fhint.css%2Fblame%2Fmaster%2FLICENSE.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
                <span class="text-gray">or</span>
                <a class="text-bold text-white no-underline" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
            </div>
        </span>
      </div>
    </div>
  </div>
</div>


  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">
</div>



  <div role="main">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode">
    <div id="js-repo-pjax-container" data-pjax-container>
      



    <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav">
      <div class="container repohead-details-container">

        <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-eye" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/chinchang/hint.css/watchers"
     aria-label="219 users are watching this repository">
    219
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-star" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z"/></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/chinchang/hint.css/stargazers"
      aria-label="7396 users starred this repository">
      7,396
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg aria-hidden="true" class="octicon octicon-repo-forked" height="16" version="1.1" viewBox="0 0 10 16" width="10"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/chinchang/hint.css/network" class="social-count"
       aria-label="724 users forked this repository">
      724
    </a>
  </li>
</ul>

        <h1 class="public ">
  <svg aria-hidden="true" class="octicon octicon-repo" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a href="/chinchang" class="url fn" rel="author">chinchang</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a href="/chinchang/hint.css" data-pjax="#js-repo-pjax-container">hint.css</a></strong>

</h1>

      </div>
      <div class="container">
        
<nav class="reponav js-repo-nav js-sidenav-container-pjax"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css" class="js-selected-navigation-item selected reponav-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /chinchang/hint.css" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a href="/chinchang/hint.css/issues" class="js-selected-navigation-item reponav-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /chinchang/hint.css/issues" itemprop="url">
        <svg aria-hidden="true" class="octicon octicon-issue-opened" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">32</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css/pulls" class="js-selected-navigation-item reponav-item" data-hotkey="g p" data-selected-links="repo_pulls /chinchang/hint.css/pulls" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-git-pull-request" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">4</span>
      <meta itemprop="position" content="3">
</a>  </span>

    <a href="/chinchang/hint.css/projects" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /chinchang/hint.css/projects">
      <svg aria-hidden="true" class="octicon octicon-project" height="16" version="1.1" viewBox="0 0 15 16" width="15"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      Projects
      <span class="Counter" >1</span>
</a>
    <a href="/chinchang/hint.css/wiki" class="js-selected-navigation-item reponav-item" data-hotkey="g w" data-selected-links="repo_wiki /chinchang/hint.css/wiki">
      <svg aria-hidden="true" class="octicon octicon-book" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M3 5h4v1H3V5zm0 3h4V7H3v1zm0 2h4V9H3v1zm11-5h-4v1h4V5zm0 2h-4v1h4V7zm0 2h-4v1h4V9zm2-6v9c0 .55-.45 1-1 1H9.5l-1 1-1-1H2c-.55 0-1-.45-1-1V3c0-.55.45-1 1-1h5.5l1 1 1-1H15c.55 0 1 .45 1 1zm-8 .5L7.5 3H2v9h6V3.5zm7-.5H9.5l-.5.5V12h6V3z"/></svg>
      Wiki
</a>

    <div class="reponav-dropdown js-menu-container">
      <button type="button" class="btn-link reponav-item reponav-dropdown js-menu-target " data-no-toggle aria-expanded="false" aria-haspopup="true">
        Insights
        <svg aria-hidden="true" class="octicon octicon-triangle-down v-align-middle text-gray" height="11" version="1.1" viewBox="0 0 12 16" width="8"><path fill-rule="evenodd" d="M0 5l6 6 6-6z"/></svg>
      </button>
      <div class="dropdown-menu-content js-menu-content">
        <div class="dropdown-menu dropdown-menu-sw">
          <a class="dropdown-item" href="/chinchang/hint.css/pulse" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-pulse" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M11.5 8L8.8 5.4 6.6 8.5 5.5 1.6 2.38 8H0v2h3.6l.9-1.8.9 5.4L9 8.5l1.6 1.5H14V8z"/></svg>
            Pulse
          </a>
          <a class="dropdown-item" href="/chinchang/hint.css/graphs" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-graph" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
            Graphs
          </a>
        </div>
      </div>
    </div>
</nav>

      </div>
    </div>

<div class="container new-discussion-timeline experiment-repo-nav">
  <div class="repository-content">

    

  <div class="wants-full-width-container"></div>

  <a href="/chinchang/hint.css/blame/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25/LICENSE.md" class="d-none js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
    <span class="css-truncate-target js-zeroclipboard-target"><span class="repo-root js-repo-root"><span class="js-path-segment"><a href="/chinchang/hint.css"><span>hint.css</span></a></span></span><span class="separator">/</span><strong class="final-path">LICENSE.md</strong></span>
    <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
  </div>

  <div class="line-age-legend">
    <span>Newer</span>
    <ol>
        <li class="heat" data-heat="1"></li>
        <li class="heat" data-heat="2"></li>
        <li class="heat" data-heat="3"></li>
        <li class="heat" data-heat="4"></li>
        <li class="heat" data-heat="5"></li>
        <li class="heat" data-heat="6"></li>
        <li class="heat" data-heat="7"></li>
        <li class="heat" data-heat="8"></li>
        <li class="heat" data-heat="9"></li>
        <li class="heat" data-heat="10"></li>
    </ol>
    <span>Older</span>
  </div>

  <div class="file">
    <div class="file-header">
      <div class="file-actions">
        <div class="BtnGroup">
          <a href="/chinchang/hint.css/raw/master/LICENSE.md" class="btn btn-sm BtnGroup-item" id="raw-url">Raw</a>
          <a href="/chinchang/hint.css/blob/master/LICENSE.md" class="btn btn-sm js-update-url-with-hash BtnGroup-item">Normal view</a>
          <a href="/chinchang/hint.css/commits/master/LICENSE.md" class="btn btn-sm BtnGroup-item" rel="nofollow">History</a>
        </div>
      </div>

  

      <div class="file-info">
        <svg aria-hidden="true" class="octicon octicon-file-text" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"/></svg>
        <span class="file-mode" title="File Mode">100644</span>
        <span class="file-info-divider"></span>
          674 lines (550 sloc)
          <span class="file-info-divider"></span>
        34.1 KB
      </div>
    </div>

    <div class="blob-wrapper">
      <table class="blame-container highlight data js-file-line-container tab-size" data-tab-size="8">
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="674">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-09-17T07:52:18Z">Sep 17, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1" class="message" data-pjax="true" title="update to commercial license">update to commercial license</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="674">
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>License</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC2"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-mh"><span class="pl-mh">###</span><span class="pl-mh"> </span>Commercial License</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC4"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC5">If you want to use Hint.css for business, commercial sites, themes, projects, and applications, the Commercial license is the appropriate license. With this option, your source code is kept proprietary. Purchase a Hint.css Commercial License at https://site.uplabs.com/posts/hint-css</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC6"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-mh"><span class="pl-mh">###</span><span class="pl-mh"> </span>Open-source License</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC8"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC9">Hint.css is free for personal use under the GNU AGPLv3.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC10"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c"><span class="pl-c1">&gt;</span> Copyright (c) 2013-2016 Kushagra Gour</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-c"></span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC13">                    GNU AFFERO GENERAL PUBLIC LICENSE</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC14">                       Version 3, 19 November 2007</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC15"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC16"> Copyright (C) 2007 Free Software Foundation, Inc. &lt;http://fsf.org/&gt;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC17"> Everyone is permitted to copy and distribute verbatim copies</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC18"> of this license document, but changing it is not allowed.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC19"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC20">                            Preamble</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC21"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC22">  The GNU Affero General Public License is a free, copyleft license for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC23">software and other kinds of works, specifically designed to ensure</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC24">cooperation with the community in the case of network server software.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC25"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC26">  The licenses for most software and other practical works are designed</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC27">to take away your freedom to share and change the works.  By contrast,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC28">our General Public Licenses are intended to guarantee your freedom to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC29">share and change all versions of a program--to make sure it remains free</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC30">software for all its users.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC31"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC32">  When we speak of free software, we are referring to freedom, not</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC33">price.  Our General Public Licenses are designed to make sure that you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC34">have the freedom to distribute copies of free software (and charge for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC35">them if you wish), that you receive source code or can get it if you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC36">want it, that you can change the software or use pieces of it in new</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC37">free programs, and that you know you can do these things.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC38"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC39">  Developers that use our General Public Licenses protect your rights</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC40">with two steps: (1) assert copyright on the software, and (2) offer</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC41">you this License which gives you legal permission to copy, distribute</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC42">and/or modify the software.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC43"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC44">  A secondary benefit of defending all users&#39; freedom is that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC45">improvements made in alternate versions of the program, if they</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC46">receive widespread use, become available for other developers to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC47">incorporate.  Many developers of free software are heartened and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC48">encouraged by the resulting cooperation.  However, in the case of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC49">software used on network servers, this result may fail to come about.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC50">The GNU General Public License permits making a modified version and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC51">letting the public access it on a server without ever releasing its</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC52">source code to the public.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC53"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC54">  The GNU Affero General Public License is designed specifically to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC55">ensure that, in such cases, the modified source code becomes available</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC56">to the community.  It requires the operator of a network server to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC57">provide the source code of the modified version running there to the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC58">users of that server.  Therefore, public use of a modified version, on</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC59">a publicly accessible server, gives the public access to the source</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC60">code of the modified version.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC61"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC62">  An older license, called the Affero General Public License and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC63">published by Affero, was designed to accomplish similar goals.  This is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC64">a different license, not a version of the Affero GPL, but Affero has</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC65">released a new version of the Affero GPL which permits relicensing under</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC66">this license.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC67"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC68">  The precise terms and conditions for copying, distribution and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC69">modification follow.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC70"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC71">                       TERMS AND CONDITIONS</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC72"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC73">  <span class="pl-v">0.</span> Definitions.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC74"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC75">  &quot;This License&quot; refers to version 3 of the GNU Affero General Public License.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC76"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC77">  &quot;Copyright&quot; also means copyright-like laws that apply to other kinds of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC78">works, such as semiconductor masks.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC79"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC80">  &quot;The Program&quot; refers to any copyrightable work licensed under this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC81">License.  Each licensee is addressed as &quot;you&quot;.  &quot;Licensees&quot; and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC82">&quot;recipients&quot; may be individuals or organizations.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC83"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC84">  To &quot;modify&quot; a work means to copy from or adapt all or part of the work</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC85">in a fashion requiring copyright permission, other than the making of an</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC86">exact copy.  The resulting work is called a &quot;modified version&quot; of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC87">earlier work or a work &quot;based on&quot; the earlier work.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC88"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC89">  A &quot;covered work&quot; means either the unmodified Program or a work based</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC90">on the Program.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC91"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC92">  To &quot;propagate&quot; a work means to do anything with it that, without</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC93">permission, would make you directly or secondarily liable for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC94">infringement under applicable copyright law, except executing it on a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC95">computer or modifying a private copy.  Propagation includes copying,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC96">distribution (with or without modification), making available to the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC97">public, and in some countries other activities as well.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC98"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC99">  To &quot;convey&quot; a work means any kind of propagation that enables other</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC100">parties to make or receive copies.  Mere interaction with a user through</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC101">a computer network, with no transfer of a copy, is not conveying.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC102"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC103">  An interactive user interface displays &quot;Appropriate Legal Notices&quot;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC104">to the extent that it includes a convenient and prominently visible</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC105">feature that (1) displays an appropriate copyright notice, and (2)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC106">tells the user that there is no warranty for the work (except to the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC107">extent that warranties are provided), that licensees may convey the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC108">work under this License, and how to view a copy of this License.  If</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC109">the interface presents a list of user commands or options, such as a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC110">menu, a prominent item in the list meets this criterion.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC111"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC112">  <span class="pl-v">1.</span> Source Code.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC113"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC114">  The &quot;source code&quot; for a work means the preferred form of the work</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC115">for making modifications to it.  &quot;Object code&quot; means any non-source</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC116">form of a work.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC117"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC118">  A &quot;Standard Interface&quot; means an interface that either is an official</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC119">standard defined by a recognized standards body, or, in the case of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC120">interfaces specified for a particular programming language, one that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC121">is widely used among developers working in that language.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC122"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC123">  The &quot;System Libraries&quot; of an executable work include anything, other</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC124">than the work as a whole, that (a) is included in the normal form of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC125">packaging a Major Component, but which is not part of that Major</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC126">Component, and (b) serves only to enable use of the work with that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC127">Major Component, or to implement a Standard Interface for which an</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC128">implementation is available to the public in source code form.  A</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC129">&quot;Major Component&quot;, in this context, means a major essential component</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC130">(kernel, window system, and so on) of the specific operating system</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC131">(if any) on which the executable work runs, or a compiler used to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC132">produce the work, or an object code interpreter used to run it.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC133"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC134">  The &quot;Corresponding Source&quot; for a work in object code form means all</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC135">the source code needed to generate, install, and (for an executable</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC136">work) run the object code and to modify the work, including scripts to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC137">control those activities.  However, it does not include the work&#39;s</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC138">System Libraries, or general-purpose tools or generally available free</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC139">programs which are used unmodified in performing those activities but</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC140">which are not part of the work.  For example, Corresponding Source</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC141">includes interface definition files associated with source files for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC142">the work, and the source code for shared libraries and dynamically</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC143">linked subprograms that the work is specifically designed to require,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC144">such as by intimate data communication or control flow between those</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC145">subprograms and other parts of the work.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC146"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC147">  The Corresponding Source need not include anything that users</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC148">can regenerate automatically from other parts of the Corresponding</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC149">Source.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC150"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC151">  The Corresponding Source for a work in source code form is that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC152">same work.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC153"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC154">  <span class="pl-v">2.</span> Basic Permissions.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC155"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC156">  All rights granted under this License are granted for the term of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC157">copyright on the Program, and are irrevocable provided the stated</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC158">conditions are met.  This License explicitly affirms your unlimited</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC159">permission to run the unmodified Program.  The output from running a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC160">covered work is covered by this License only if the output, given its</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC161">content, constitutes a covered work.  This License acknowledges your</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC162">rights of fair use or other equivalent, as provided by copyright law.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC163"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC164">  You may make, run and propagate covered works that you do not</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC165">convey, without conditions so long as your license otherwise remains</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC166">in force.  You may convey covered works to others for the sole purpose</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L167">167</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC167">of having them make modifications exclusively for you, or provide you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L168">168</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC168">with facilities for running those works, provided that you comply with</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L169">169</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC169">the terms of this License in conveying all material for which you do</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L170">170</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC170">not control copyright.  Those thus making or running the covered works</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L171">171</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC171">for you must do so exclusively on your behalf, under your direction</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L172">172</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC172">and control, on terms that prohibit them from making any copies of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L173">173</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC173">your copyrighted material outside their relationship with you.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L174">174</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC174"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L175">175</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC175">  Conveying under any other circumstances is permitted solely under</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L176">176</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC176">the conditions stated below.  Sublicensing is not allowed; section 10</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L177">177</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC177">makes it unnecessary.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L178">178</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC178"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L179">179</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC179">  <span class="pl-v">3.</span> Protecting Users&#39; Legal Rights From Anti-Circumvention Law.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L180">180</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC180"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L181">181</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC181">  No covered work shall be deemed part of an effective technological</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L182">182</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC182">measure under any applicable law fulfilling obligations under article</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L183">183</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC183">11 of the WIPO copyright treaty adopted on 20 December 1996, or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L184">184</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC184">similar laws prohibiting or restricting circumvention of such</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L185">185</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC185">measures.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L186">186</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC186"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L187">187</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC187">  When you convey a covered work, you waive any legal power to forbid</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L188">188</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC188">circumvention of technological measures to the extent such circumvention</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L189">189</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC189">is effected by exercising rights under this License with respect to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L190">190</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC190">the covered work, and you disclaim any intention to limit operation or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L191">191</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC191">modification of the work as a means of enforcing, against the work&#39;s</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L192">192</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC192">users, your or third parties&#39; legal rights to forbid circumvention of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L193">193</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC193">technological measures.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L194">194</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC194"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L195">195</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC195">  <span class="pl-v">4.</span> Conveying Verbatim Copies.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L196">196</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC196"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L197">197</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC197">  You may convey verbatim copies of the Program&#39;s source code as you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L198">198</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC198">receive it, in any medium, provided that you conspicuously and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L199">199</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC199">appropriately publish on each copy an appropriate copyright notice;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L200">200</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC200">keep intact all notices stating that this License and any</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L201">201</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC201">non-permissive terms added in accord with section 7 apply to the code;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L202">202</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC202">keep intact all notices of the absence of any warranty; and give all</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L203">203</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC203">recipients a copy of this License along with the Program.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L204">204</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC204"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L205">205</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC205">  You may charge any price or no price for each copy that you convey,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L206">206</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC206">and you may offer support or warranty protection for a fee.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L207">207</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC207"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L208">208</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC208">  <span class="pl-v">5.</span> Conveying Modified Source Versions.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L209">209</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC209"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L210">210</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC210">  You may convey a work based on the Program, or the modifications to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L211">211</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC211">produce it from the Program, in the form of source code under the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L212">212</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC212">terms of section 4, provided that you also meet all of these conditions:</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L213">213</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC213"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L214">214</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC214">    a) The work must carry prominent notices stating that you modified</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L215">215</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC215">    it, and giving a relevant date.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L216">216</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC216"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L217">217</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC217">    b) The work must carry prominent notices stating that it is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L218">218</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC218">    released under this License and any conditions added under section</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L219">219</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC219">    <span class="pl-v">7.</span>  This requirement modifies the requirement in section 4 to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L220">220</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC220">    &quot;keep intact all notices&quot;.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L221">221</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC221"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L222">222</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC222">    c) You must license the entire work, as a whole, under this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L223">223</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC223">    License to anyone who comes into possession of a copy.  This</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L224">224</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC224">    License will therefore apply, along with any applicable section 7</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L225">225</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC225">    additional terms, to the whole of the work, and all its parts,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L226">226</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC226">    regardless of how they are packaged.  This License gives no</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L227">227</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC227">    permission to license the work in any other way, but it does not</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L228">228</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC228">    invalidate such permission if you have separately received it.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L229">229</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC229"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L230">230</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC230">    d) If the work has interactive user interfaces, each must display</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L231">231</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC231">    Appropriate Legal Notices; however, if the Program has interactive</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L232">232</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC232">    interfaces that do not display Appropriate Legal Notices, your</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L233">233</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC233">    work need not make them do so.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L234">234</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC234"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L235">235</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC235">  A compilation of a covered work with other separate and independent</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L236">236</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC236">works, which are not by their nature extensions of the covered work,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L237">237</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC237">and which are not combined with it such as to form a larger program,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L238">238</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC238">in or on a volume of a storage or distribution medium, is called an</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L239">239</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC239">&quot;aggregate&quot; if the compilation and its resulting copyright are not</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L240">240</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC240">used to limit the access or legal rights of the compilation&#39;s users</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L241">241</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC241">beyond what the individual works permit.  Inclusion of a covered work</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L242">242</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC242">in an aggregate does not cause this License to apply to the other</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L243">243</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC243">parts of the aggregate.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L244">244</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC244"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L245">245</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC245">  <span class="pl-v">6.</span> Conveying Non-Source Forms.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L246">246</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC246"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L247">247</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC247">  You may convey a covered work in object code form under the terms</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L248">248</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC248">of sections 4 and 5, provided that you also convey the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L249">249</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC249">machine-readable Corresponding Source under the terms of this License,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L250">250</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC250">in one of these ways:</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L251">251</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC251"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L252">252</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC252">    a) Convey the object code in, or embodied in, a physical product</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L253">253</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC253">    (including a physical distribution medium), accompanied by the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L254">254</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC254">    Corresponding Source fixed on a durable physical medium</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L255">255</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC255">    customarily used for software interchange.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L256">256</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC256"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L257">257</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC257">    b) Convey the object code in, or embodied in, a physical product</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L258">258</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC258">    (including a physical distribution medium), accompanied by a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L259">259</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC259">    written offer, valid for at least three years and valid for as</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L260">260</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC260">    long as you offer spare parts or customer support for that product</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L261">261</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC261">    model, to give anyone who possesses the object code either (1) a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L262">262</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC262">    copy of the Corresponding Source for all the software in the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L263">263</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC263">    product that is covered by this License, on a durable physical</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L264">264</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC264">    medium customarily used for software interchange, for a price no</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L265">265</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC265">    more than your reasonable cost of physically performing this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L266">266</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC266">    conveying of source, or (2) access to copy the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L267">267</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC267">    Corresponding Source from a network server at no charge.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L268">268</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC268"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L269">269</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC269">    c) Convey individual copies of the object code with a copy of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L270">270</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC270">    written offer to provide the Corresponding Source.  This</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L271">271</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC271">    alternative is allowed only occasionally and noncommercially, and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L272">272</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC272">    only if you received the object code with such an offer, in accord</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L273">273</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC273">    with subsection 6b.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L274">274</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC274"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L275">275</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC275">    d) Convey the object code by offering access from a designated</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L276">276</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC276">    place (gratis or for a charge), and offer equivalent access to the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L277">277</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC277">    Corresponding Source in the same way through the same place at no</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L278">278</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC278">    further charge.  You need not require recipients to copy the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L279">279</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC279">    Corresponding Source along with the object code.  If the place to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L280">280</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC280">    copy the object code is a network server, the Corresponding Source</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L281">281</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC281">    may be on a different server (operated by you or a third party)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L282">282</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC282">    that supports equivalent copying facilities, provided you maintain</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L283">283</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC283">    clear directions next to the object code saying where to find the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L284">284</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC284">    Corresponding Source.  Regardless of what server hosts the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L285">285</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC285">    Corresponding Source, you remain obligated to ensure that it is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L286">286</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC286">    available for as long as needed to satisfy these requirements.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L287">287</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC287"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L288">288</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC288">    e) Convey the object code using peer-to-peer transmission, provided</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L289">289</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC289">    you inform other peers where the object code and Corresponding</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L290">290</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC290">    Source of the work are being offered to the general public at no</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L291">291</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC291">    charge under subsection 6d.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L292">292</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC292"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L293">293</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC293">  A separable portion of the object code, whose source code is excluded</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L294">294</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC294">from the Corresponding Source as a System Library, need not be</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L295">295</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC295">included in conveying the object code work.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L296">296</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC296"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L297">297</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC297">  A &quot;User Product&quot; is either (1) a &quot;consumer product&quot;, which means any</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L298">298</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC298">tangible personal property which is normally used for personal, family,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L299">299</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC299">or household purposes, or (2) anything designed or sold for incorporation</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L300">300</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC300">into a dwelling.  In determining whether a product is a consumer product,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L301">301</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC301">doubtful cases shall be resolved in favor of coverage.  For a particular</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L302">302</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC302">product received by a particular user, &quot;normally used&quot; refers to a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L303">303</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC303">typical or common use of that class of product, regardless of the status</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L304">304</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC304">of the particular user or of the way in which the particular user</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L305">305</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC305">actually uses, or expects or is expected to use, the product.  A product</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L306">306</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC306">is a consumer product regardless of whether the product has substantial</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L307">307</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC307">commercial, industrial or non-consumer uses, unless such uses represent</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L308">308</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC308">the only significant mode of use of the product.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L309">309</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC309"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L310">310</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC310">  &quot;Installation Information&quot; for a User Product means any methods,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L311">311</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC311">procedures, authorization keys, or other information required to install</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L312">312</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC312">and execute modified versions of a covered work in that User Product from</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L313">313</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC313">a modified version of its Corresponding Source.  The information must</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L314">314</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC314">suffice to ensure that the continued functioning of the modified object</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L315">315</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC315">code is in no case prevented or interfered with solely because</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L316">316</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC316">modification has been made.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L317">317</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC317"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L318">318</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC318">  If you convey an object code work under this section in, or with, or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L319">319</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC319">specifically for use in, a User Product, and the conveying occurs as</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L320">320</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC320">part of a transaction in which the right of possession and use of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L321">321</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC321">User Product is transferred to the recipient in perpetuity or for a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L322">322</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC322">fixed term (regardless of how the transaction is characterized), the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L323">323</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC323">Corresponding Source conveyed under this section must be accompanied</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L324">324</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC324">by the Installation Information.  But this requirement does not apply</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L325">325</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC325">if neither you nor any third party retains the ability to install</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L326">326</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC326">modified object code on the User Product (for example, the work has</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L327">327</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC327">been installed in ROM).</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L328">328</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC328"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L329">329</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC329">  The requirement to provide Installation Information does not include a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L330">330</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC330">requirement to continue to provide support service, warranty, or updates</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L331">331</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC331">for a work that has been modified or installed by the recipient, or for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L332">332</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC332">the User Product in which it has been modified or installed.  Access to a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L333">333</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC333">network may be denied when the modification itself materially and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L334">334</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC334">adversely affects the operation of the network or violates the rules and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L335">335</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC335">protocols for communication across the network.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L336">336</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC336"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L337">337</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC337">  Corresponding Source conveyed, and Installation Information provided,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L338">338</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC338">in accord with this section must be in a format that is publicly</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L339">339</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC339">documented (and with an implementation available to the public in</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L340">340</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC340">source code form), and must require no special password or key for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L341">341</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC341">unpacking, reading or copying.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L342">342</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC342"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L343">343</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC343">  <span class="pl-v">7.</span> Additional Terms.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L344">344</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC344"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L345">345</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC345">  &quot;Additional permissions&quot; are terms that supplement the terms of this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L346">346</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC346">License by making exceptions from one or more of its conditions.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L347">347</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC347">Additional permissions that are applicable to the entire Program shall</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L348">348</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC348">be treated as though they were included in this License, to the extent</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L349">349</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC349">that they are valid under applicable law.  If additional permissions</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L350">350</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC350">apply only to part of the Program, that part may be used separately</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L351">351</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC351">under those permissions, but the entire Program remains governed by</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L352">352</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC352">this License without regard to the additional permissions.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L353">353</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC353"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L354">354</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC354">  When you convey a copy of a covered work, you may at your option</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L355">355</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC355">remove any additional permissions from that copy, or from any part of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L356">356</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC356">it.  (Additional permissions may be written to require their own</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L357">357</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC357">removal in certain cases when you modify the work.)  You may place</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L358">358</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC358">additional permissions on material, added by you to a covered work,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L359">359</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC359">for which you have or can give appropriate copyright permission.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L360">360</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC360"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L361">361</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC361">  Notwithstanding any other provision of this License, for material you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L362">362</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC362">add to a covered work, you may (if authorized by the copyright holders of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L363">363</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC363">that material) supplement the terms of this License with terms:</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L364">364</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC364"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L365">365</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC365">    a) Disclaiming warranty or limiting liability differently from the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L366">366</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC366">    terms of sections 15 and 16 of this License; or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L367">367</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC367"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L368">368</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC368">    b) Requiring preservation of specified reasonable legal notices or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L369">369</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC369">    author attributions in that material or in the Appropriate Legal</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L370">370</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC370">    Notices displayed by works containing it; or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L371">371</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC371"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L372">372</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC372">    c) Prohibiting misrepresentation of the origin of that material, or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L373">373</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC373">    requiring that modified versions of such material be marked in</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L374">374</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC374">    reasonable ways as different from the original version; or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L375">375</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC375"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L376">376</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC376">    d) Limiting the use for publicity purposes of names of licensors or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L377">377</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC377">    authors of the material; or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L378">378</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC378"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L379">379</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC379">    e) Declining to grant rights under trademark law for use of some</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L380">380</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC380">    trade names, trademarks, or service marks; or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L381">381</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC381"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L382">382</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC382">    f) Requiring indemnification of licensors and authors of that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L383">383</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC383">    material by anyone who conveys the material (or modified versions of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L384">384</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC384">    it) with contractual assumptions of liability to the recipient, for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L385">385</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC385">    any liability that these contractual assumptions directly impose on</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L386">386</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC386">    those licensors and authors.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L387">387</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC387"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L388">388</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC388">  All other non-permissive additional terms are considered &quot;further</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L389">389</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC389">restrictions&quot; within the meaning of section 10.  If the Program as you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L390">390</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC390">received it, or any part of it, contains a notice stating that it is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L391">391</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC391">governed by this License along with a term that is a further</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L392">392</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC392">restriction, you may remove that term.  If a license document contains</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L393">393</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC393">a further restriction but permits relicensing or conveying under this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L394">394</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC394">License, you may add to a covered work material governed by the terms</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L395">395</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC395">of that license document, provided that the further restriction does</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L396">396</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC396">not survive such relicensing or conveying.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L397">397</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC397"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L398">398</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC398">  If you add terms to a covered work in accord with this section, you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L399">399</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC399">must place, in the relevant source files, a statement of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L400">400</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC400">additional terms that apply to those files, or a notice indicating</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L401">401</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC401">where to find the applicable terms.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L402">402</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC402"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L403">403</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC403">  Additional terms, permissive or non-permissive, may be stated in the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L404">404</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC404">form of a separately written license, or stated as exceptions;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L405">405</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC405">the above requirements apply either way.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L406">406</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC406"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L407">407</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC407">  <span class="pl-v">8.</span> Termination.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L408">408</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC408"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L409">409</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC409">  You may not propagate or modify a covered work except as expressly</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L410">410</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC410">provided under this License.  Any attempt otherwise to propagate or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L411">411</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC411">modify it is void, and will automatically terminate your rights under</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L412">412</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC412">this License (including any patent licenses granted under the third</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L413">413</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC413">paragraph of section 11).</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L414">414</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC414"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L415">415</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC415">  However, if you cease all violation of this License, then your</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L416">416</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC416">license from a particular copyright holder is reinstated (a)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L417">417</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC417">provisionally, unless and until the copyright holder explicitly and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L418">418</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC418">finally terminates your license, and (b) permanently, if the copyright</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L419">419</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC419">holder fails to notify you of the violation by some reasonable means</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L420">420</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC420">prior to 60 days after the cessation.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L421">421</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC421"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L422">422</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC422">  Moreover, your license from a particular copyright holder is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L423">423</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC423">reinstated permanently if the copyright holder notifies you of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L424">424</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC424">violation by some reasonable means, this is the first time you have</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L425">425</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC425">received notice of violation of this License (for any work) from that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L426">426</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC426">copyright holder, and you cure the violation prior to 30 days after</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L427">427</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC427">your receipt of the notice.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L428">428</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC428"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L429">429</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC429">  Termination of your rights under this section does not terminate the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L430">430</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC430">licenses of parties who have received copies or rights from you under</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L431">431</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC431">this License.  If your rights have been terminated and not permanently</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L432">432</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC432">reinstated, you do not qualify to receive new licenses for the same</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L433">433</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC433">material under section 10.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L434">434</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC434"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L435">435</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC435">  <span class="pl-v">9.</span> Acceptance Not Required for Having Copies.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L436">436</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC436"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L437">437</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC437">  You are not required to accept this License in order to receive or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L438">438</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC438">run a copy of the Program.  Ancillary propagation of a covered work</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L439">439</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC439">occurring solely as a consequence of using peer-to-peer transmission</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L440">440</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC440">to receive a copy likewise does not require acceptance.  However,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L441">441</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC441">nothing other than this License grants you permission to propagate or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L442">442</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC442">modify any covered work.  These actions infringe copyright if you do</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L443">443</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC443">not accept this License.  Therefore, by modifying or propagating a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L444">444</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC444">covered work, you indicate your acceptance of this License to do so.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L445">445</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC445"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L446">446</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC446">  <span class="pl-v">10.</span> Automatic Licensing of Downstream Recipients.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L447">447</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC447"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L448">448</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC448">  Each time you convey a covered work, the recipient automatically</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L449">449</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC449">receives a license from the original licensors, to run, modify and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L450">450</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC450">propagate that work, subject to this License.  You are not responsible</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L451">451</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC451">for enforcing compliance by third parties with this License.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L452">452</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC452"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L453">453</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC453">  An &quot;entity transaction&quot; is a transaction transferring control of an</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L454">454</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC454">organization, or substantially all assets of one, or subdividing an</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L455">455</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC455">organization, or merging organizations.  If propagation of a covered</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L456">456</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC456">work results from an entity transaction, each party to that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L457">457</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC457">transaction who receives a copy of the work also receives whatever</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L458">458</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC458">licenses to the work the party&#39;s predecessor in interest had or could</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L459">459</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC459">give under the previous paragraph, plus a right to possession of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L460">460</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC460">Corresponding Source of the work from the predecessor in interest, if</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L461">461</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC461">the predecessor has it or can get it with reasonable efforts.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L462">462</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC462"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L463">463</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC463">  You may not impose any further restrictions on the exercise of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L464">464</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC464">rights granted or affirmed under this License.  For example, you may</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L465">465</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC465">not impose a license fee, royalty, or other charge for exercise of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L466">466</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC466">rights granted under this License, and you may not initiate litigation</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L467">467</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC467">(including a cross-claim or counterclaim in a lawsuit) alleging that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L468">468</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC468">any patent claim is infringed by making, using, selling, offering for</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L469">469</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC469">sale, or importing the Program or any portion of it.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L470">470</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC470"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L471">471</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC471">  <span class="pl-v">11.</span> Patents.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L472">472</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC472"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L473">473</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC473">  A &quot;contributor&quot; is a copyright holder who authorizes use under this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L474">474</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC474">License of the Program or a work on which the Program is based.  The</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L475">475</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC475">work thus licensed is called the contributor&#39;s &quot;contributor version&quot;.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L476">476</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC476"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L477">477</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC477">  A contributor&#39;s &quot;essential patent claims&quot; are all patent claims</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L478">478</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC478">owned or controlled by the contributor, whether already acquired or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L479">479</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC479">hereafter acquired, that would be infringed by some manner, permitted</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L480">480</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC480">by this License, of making, using, or selling its contributor version,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L481">481</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC481">but do not include claims that would be infringed only as a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L482">482</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC482">consequence of further modification of the contributor version.  For</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L483">483</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC483">purposes of this definition, &quot;control&quot; includes the right to grant</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L484">484</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC484">patent sublicenses in a manner consistent with the requirements of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L485">485</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC485">this License.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L486">486</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC486"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L487">487</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC487">  Each contributor grants you a non-exclusive, worldwide, royalty-free</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L488">488</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC488">patent license under the contributor&#39;s essential patent claims, to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L489">489</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC489">make, use, sell, offer for sale, import and otherwise run, modify and</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L490">490</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC490">propagate the contents of its contributor version.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L491">491</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC491"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L492">492</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC492">  In the following three paragraphs, a &quot;patent license&quot; is any express</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L493">493</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC493">agreement or commitment, however denominated, not to enforce a patent</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L494">494</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC494">(such as an express permission to practice a patent or covenant not to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L495">495</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC495">sue for patent infringement).  To &quot;grant&quot; such a patent license to a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L496">496</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC496">party means to make such an agreement or commitment not to enforce a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L497">497</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC497">patent against the party.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L498">498</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC498"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L499">499</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC499">  If you convey a covered work, knowingly relying on a patent license,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L500">500</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC500">and the Corresponding Source of the work is not available for anyone</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L501">501</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC501">to copy, free of charge and under the terms of this License, through a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L502">502</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC502">publicly available network server or other readily accessible means,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L503">503</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC503">then you must either (1) cause the Corresponding Source to be so</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L504">504</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC504">available, or (2) arrange to deprive yourself of the benefit of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L505">505</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC505">patent license for this particular work, or (3) arrange, in a manner</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L506">506</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC506">consistent with the requirements of this License, to extend the patent</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L507">507</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC507">license to downstream recipients.  &quot;Knowingly relying&quot; means you have</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L508">508</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC508">actual knowledge that, but for the patent license, your conveying the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L509">509</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC509">covered work in a country, or your recipient&#39;s use of the covered work</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L510">510</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC510">in a country, would infringe one or more identifiable patents in that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L511">511</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC511">country that you have reason to believe are valid.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L512">512</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC512"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L513">513</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC513">  If, pursuant to or in connection with a single transaction or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L514">514</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC514">arrangement, you convey, or propagate by procuring conveyance of, a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L515">515</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC515">covered work, and grant a patent license to some of the parties</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L516">516</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC516">receiving the covered work authorizing them to use, propagate, modify</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L517">517</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC517">or convey a specific copy of the covered work, then the patent license</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L518">518</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC518">you grant is automatically extended to all recipients of the covered</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L519">519</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC519">work and works based on it.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L520">520</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC520"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L521">521</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC521">  A patent license is &quot;discriminatory&quot; if it does not include within</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L522">522</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC522">the scope of its coverage, prohibits the exercise of, or is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L523">523</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC523">conditioned on the non-exercise of one or more of the rights that are</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L524">524</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC524">specifically granted under this License.  You may not convey a covered</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L525">525</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC525">work if you are a party to an arrangement with a third party that is</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L526">526</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC526">in the business of distributing software, under which you make payment</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L527">527</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC527">to the third party based on the extent of your activity of conveying</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L528">528</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC528">the work, and under which the third party grants, to any of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L529">529</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC529">parties who would receive the covered work from you, a discriminatory</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L530">530</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC530">patent license (a) in connection with copies of the covered work</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L531">531</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC531">conveyed by you (or copies made from those copies), or (b) primarily</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L532">532</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC532">for and in connection with specific products or compilations that</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L533">533</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC533">contain the covered work, unless you entered into that arrangement,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L534">534</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC534">or that patent license was granted, prior to 28 March 2007.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L535">535</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC535"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L536">536</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC536">  Nothing in this License shall be construed as excluding or limiting</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L537">537</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC537">any implied license or other defenses to infringement that may</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L538">538</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC538">otherwise be available to you under applicable patent law.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L539">539</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC539"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L540">540</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC540">  <span class="pl-v">12.</span> No Surrender of Others&#39; Freedom.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L541">541</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC541"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L542">542</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC542">  If conditions are imposed on you (whether by court order, agreement or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L543">543</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC543">otherwise) that contradict the conditions of this License, they do not</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L544">544</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC544">excuse you from the conditions of this License.  If you cannot convey a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L545">545</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC545">covered work so as to satisfy simultaneously your obligations under this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L546">546</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC546">License and any other pertinent obligations, then as a consequence you may</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L547">547</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC547">not convey it at all.  For example, if you agree to terms that obligate you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L548">548</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC548">to collect a royalty for further conveying from those to whom you convey</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L549">549</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC549">the Program, the only way you could satisfy both those terms and this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L550">550</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC550">License would be to refrain entirely from conveying the Program.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L551">551</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC551"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L552">552</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC552">  <span class="pl-v">13.</span> Remote Network Interaction; Use with the GNU General Public License.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L553">553</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC553"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L554">554</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC554">  Notwithstanding any other provision of this License, if you modify the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L555">555</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC555">Program, your modified version must prominently offer all users</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L556">556</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC556">interacting with it remotely through a computer network (if your version</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L557">557</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC557">supports such interaction) an opportunity to receive the Corresponding</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L558">558</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC558">Source of your version by providing access to the Corresponding Source</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L559">559</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC559">from a network server at no charge, through some standard or customary</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L560">560</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC560">means of facilitating copying of software.  This Corresponding Source</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L561">561</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC561">shall include the Corresponding Source for any work covered by version 3</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L562">562</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC562">of the GNU General Public License that is incorporated pursuant to the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L563">563</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC563">following paragraph.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L564">564</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC564"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L565">565</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC565">  Notwithstanding any other provision of this License, you have</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L566">566</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC566">permission to link or combine any covered work with a work licensed</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L567">567</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC567">under version 3 of the GNU General Public License into a single</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L568">568</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC568">combined work, and to convey the resulting work.  The terms of this</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L569">569</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC569">License will continue to apply to the part which is the covered work,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L570">570</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC570">but the work with which it is combined will remain governed by version</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L571">571</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC571">3 of the GNU General Public License.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L572">572</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC572"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L573">573</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC573">  <span class="pl-v">14.</span> Revised Versions of this License.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L574">574</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC574"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L575">575</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC575">  The Free Software Foundation may publish revised and/or new versions of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L576">576</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC576">the GNU Affero General Public License from time to time.  Such new versions</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L577">577</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC577">will be similar in spirit to the present version, but may differ in detail to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L578">578</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC578">address new problems or concerns.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L579">579</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC579"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L580">580</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC580">  Each version is given a distinguishing version number.  If the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L581">581</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC581">Program specifies that a certain numbered version of the GNU Affero General</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L582">582</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC582">Public License &quot;or any later version&quot; applies to it, you have the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L583">583</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC583">option of following the terms and conditions either of that numbered</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L584">584</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC584">version or of any later version published by the Free Software</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L585">585</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC585">Foundation.  If the Program does not specify a version number of the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L586">586</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC586">GNU Affero General Public License, you may choose any version ever published</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L587">587</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC587">by the Free Software Foundation.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L588">588</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC588"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L589">589</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC589">  If the Program specifies that a proxy can decide which future</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L590">590</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC590">versions of the GNU Affero General Public License can be used, that proxy&#39;s</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L591">591</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC591">public statement of acceptance of a version permanently authorizes you</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L592">592</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC592">to choose that version for the Program.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L593">593</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC593"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L594">594</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC594">  Later license versions may give you additional or different</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L595">595</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC595">permissions.  However, no additional obligations are imposed on any</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L596">596</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC596">author or copyright holder as a result of your choosing to follow a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L597">597</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC597">later version.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L598">598</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC598"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L599">599</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC599">  <span class="pl-v">15.</span> Disclaimer of Warranty.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L600">600</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC600"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L601">601</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC601">  THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L602">602</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC602">APPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L603">603</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC603">HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM &quot;AS IS&quot; WITHOUT WARRANTY</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L604">604</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC604">OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L605">605</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC605">THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L606">606</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC606">PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L607">607</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC607">IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L608">608</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC608">ALL NECESSARY SERVICING, REPAIR OR CORRECTION.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L609">609</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC609"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L610">610</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC610">  <span class="pl-v">16.</span> Limitation of Liability.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L611">611</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC611"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L612">612</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC612">  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L613">613</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC613">WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L614">614</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC614">THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L615">615</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC615">GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L616">616</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC616">USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L617">617</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC617">DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L618">618</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC618">PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L619">619</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC619">EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L620">620</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC620">SUCH DAMAGES.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L621">621</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC621"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L622">622</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC622">  <span class="pl-v">17.</span> Interpretation of Sections 15 and 16.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L623">623</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC623"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L624">624</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC624">  If the disclaimer of warranty and limitation of liability provided</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L625">625</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC625">above cannot be given local legal effect according to their terms,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L626">626</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC626">reviewing courts shall apply local law that most closely approximates</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L627">627</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC627">an absolute waiver of all civil liability in connection with the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L628">628</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC628">Program, unless a warranty or assumption of liability accompanies a</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L629">629</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC629">copy of the Program in return for a fee.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L630">630</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC630"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L631">631</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC631">                     END OF TERMS AND CONDITIONS</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L632">632</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC632"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L633">633</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC633">            How to Apply These Terms to Your New Programs</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L634">634</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC634"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L635">635</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC635">  If you develop a new program, and you want it to be of the greatest</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L636">636</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC636">possible use to the public, the best way to achieve this is to make it</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L637">637</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC637">free software which everyone can redistribute and change under these terms.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L638">638</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC638"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L639">639</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC639">  To do so, attach the following notices to the program.  It is safest</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L640">640</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC640">to attach them to the start of each source file to most effectively</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L641">641</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC641">state the exclusion of warranty; and each file should have at least</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L642">642</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC642">the &quot;copyright&quot; line and a pointer to where the full notice is found.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L643">643</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC643"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L644">644</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC644">    &lt;one line to give the program&#39;s name and a brief idea of what it does.&gt;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L645">645</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC645">    Copyright (C) &lt;year&gt;  &lt;name of author&gt;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L646">646</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC646"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L647">647</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC647">    This program is free software: you can redistribute it and/or modify</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L648">648</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC648">    it under the terms of the GNU Affero General Public License as published</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L649">649</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC649">    by the Free Software Foundation, either version 3 of the License, or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L650">650</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC650">    (at your option) any later version.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L651">651</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC651"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L652">652</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC652">    This program is distributed in the hope that it will be useful,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L653">653</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC653">    but WITHOUT ANY WARRANTY; without even the implied warranty of</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L654">654</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC654">    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L655">655</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC655">    GNU Affero General Public License for more details.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L656">656</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC656"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L657">657</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC657">    You should have received a copy of the GNU Affero General Public License</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L658">658</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC658">    along with this program.  If not, see &lt;http://www.gnu.org/licenses/&gt;.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L659">659</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC659"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L660">660</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC660">Also add information on how to contact you by electronic and paper mail.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L661">661</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC661"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L662">662</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC662">  If your software can interact with users remotely through a computer</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L663">663</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC663">network, you should also make sure that it provides a way for users to</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L664">664</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC664">get its source.  For example, if your program is a web application, its</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L665">665</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC665">interface could display a &quot;Source&quot; link that leads users to an archive</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L666">666</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC666">of the code.  There are many ways you could offer source, and different</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L667">667</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC667">solutions will be better for different programs; see section 13 for the</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L668">668</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC668">specific requirements.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L669">669</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC669"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L670">670</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC670">  You should also get your employer (if you work as a programmer) or school,</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L671">671</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC671">if any, to sign a &quot;copyright disclaimer&quot; for the program, if necessary.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L672">672</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC672">For more information on this, and how to apply and follow the GNU AGPL, see</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L673">673</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC673">&lt;http://www.gnu.org/licenses/&gt;.</td>
              </tr>
          </tbody>
      </table>
    </div>

  </div>


  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

      
<div class="container-lg site-footer-container">
  <div class="site-footer " role="contentinfo">
    <ul class="site-footer-links float-right">
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact GitHub</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage" class="site-footer-mark" title="GitHub">
      <svg aria-hidden="true" class="octicon octicon-mark-github" height="24" version="1.1" viewBox="0 0 16 16" width="24"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2017 <span title="0.15131s from unicorn-2435208346-1vgdg">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a href="https://help.github.com" data-ga-click="Footer, go to help, text:help">Help</a></li>
    </ul>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <button type="button" class="flash-close js-flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
    You can't perform that action at this time.
  </div>


    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/compat-91f98c37fc84eac24836eec2567e9912742094369a04c4eba6e3cd1fa18902d9.js"></script>
    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-fb7732750125d3d783cd735f5f1ecddc0fab988ecd5bd8ce63c326337b7c4de6.js"></script>
    
    <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github-da8e77af323b7cf0c46c7ce4e7a65719fb641271a5d4d8cc9010b77f135085d5.js"></script>
    
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
  </div>
</div>


  </body>
</html>

