





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://assets-cdn.github.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/frameworks-4324702744188e5d6edc78c06517458705b8d6596db5054c244444b56c494c99.css" media="all" rel="stylesheet" />
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github-76f99dd07480164b7f348c67361a5a5cdd3797ef4f3f6ceab380ecc0ae2a2f5e.css" media="all" rel="stylesheet" />
  
  
  <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/site-5844159898e5c5251fccf0ea193404819fe2442dabac39f18424c78b5d7539a1.css" media="all" rel="stylesheet" />
  

  <meta name="viewport" content="width=device-width">
  
  <title>hint.css/README.md at master · chinchang/hint.css · GitHub</title>
  <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta content="https://avatars2.githubusercontent.com/u/379918?v=4&amp;s=400" property="og:image" /><meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="chinchang/hint.css" property="og:title" /><meta content="https://github.com/chinchang/hint.css" property="og:url" /><meta content="hint.css - A CSS only tooltip library for your lovely websites." property="og:description" />

  <link rel="assets" href="https://assets-cdn.github.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="623D:F046:136569:1E3472:5971A9EA" data-pjax-transient>
  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

  <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
<meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-analytics" content="UA-3769691-2">

<meta content="collector.githubapp.com" name="octolytics-host" /><meta content="github" name="octolytics-app-id" /><meta content="https://collector.githubapp.com/github-external/browser_event" name="octolytics-event-url" /><meta content="623D:F046:136569:1E3472:5971A9EA" name="octolytics-dimension-request_id" /><meta content="sea" name="octolytics-dimension-region_edge" /><meta content="iad" name="octolytics-dimension-region_render" />
<meta content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/blame" data-pjax-transient="true" name="analytics-location" />




  <meta class="js-ga-set" name="dimension1" content="Logged Out">


  

      <meta name="hostname" content="github.com">
  <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="YzAyYmYwZjlhMmY4N2FlZDA0ZDhhYWFkY2UwOWIxMTEzYzc5MDYxMDAyMzVjMjBlNzY0N2U5ZWI4N2QzMTdiMnx7InJlbW90ZV9hZGRyZXNzIjoiNzQuNTAuMjEzLjgwIiwicmVxdWVzdF9pZCI6IjYyM0Q6RjA0NjoxMzY1Njk6MUUzNDcyOjU5NzFBOUVBIiwidGltZXN0YW1wIjoxNTAwNjIxMjkwLCJob3N0IjoiZ2l0aHViLmNvbSJ9">


  <meta name="html-safe-nonce" content="170d70b3360b0e2e3b004c56ca74ac248bc41cff">

  <meta http-equiv="x-pjax-version" content="97722c27e681dcd9509bf112a4333d9e">
  

      <link href="https://github.com/chinchang/hint.css/commits/master.atom" rel="alternate" title="Recent Commits to hint.css:master" type="application/atom+xml">

  <meta name="description" content="hint.css - A CSS only tooltip library for your lovely websites.">
  <meta name="go-import" content="github.com/chinchang/hint.css git https://github.com/chinchang/hint.css.git">

  <meta content="379918" name="octolytics-dimension-user_id" /><meta content="chinchang" name="octolytics-dimension-user_login" /><meta content="7379964" name="octolytics-dimension-repository_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="7379964" name="octolytics-dimension-repository_network_root_id" /><meta content="chinchang/hint.css" name="octolytics-dimension-repository_network_root_nwo" /><meta content="false" name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" />




  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://assets-cdn.github.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



  </head>

  <body class="logged-out env-production full-width">
    



  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    



        <div class="header header-logged-out position-relative f4 py-3" role="banner">
  <div class="container-lg px-3 clearfix">
    <div class="d-flex flex-justify-between">
      <div class="d-flex">
        <a class="header-logo-invertocat my-0" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
          <svg aria-hidden="true" class="octicon octicon-mark-github" height="32" version="1.1" viewBox="0 0 16 16" width="32"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>

        <div class="header-sitemenu clearfix">
            <nav>
              <ul class="d-flex list-style-none">
                  <li class="ml-2">
                    <a href="/features" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:features" data-selected-links="/features /features">
                      Features
</a>                  </li>
                  <li class="ml-4">
                    <a href="/business" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:business" data-selected-links="/business /business/security /business/customers /business">
                      Business
</a>                  </li>

                  <li class="ml-4">
                    <a href="/explore" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:explore" data-selected-links="/explore /trending /trending/developers /integrations /integrations/feature/code /integrations/feature/collaborate /integrations/feature/ship /showcases /explore">
                      Explore
</a>                  </li>

                  <li class="ml-4">
                        <a href="/marketplace" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:marketplace" data-selected-links=" /marketplace">
                          Marketplace
</a>                  </li>
                  <li class="ml-4">
                    <a href="/pricing" class="js-selected-navigation-item header-navlink px-0 py-2 m-0" data-ga-click="Header, click, Nav menu - item:pricing" data-selected-links="/pricing /pricing/developer /pricing/team /pricing/business-hosted /pricing/business-enterprise /pricing">
                      Pricing
</a>                  </li>
              </ul>
            </nav>
        </div>
      </div>

      <div class="d-flex">
          <div class="mt-1 mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search" role="search">
  <!-- '"` --><!-- </textarea></xmp> --></option></form><form accept-charset="UTF-8" action="/chinchang/hint.css/search" class="js-site-search-form" data-scoped-search-url="/chinchang/hint.css/search" data-unscoped-search-url="/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
    <label class="form-control header-search-wrapper js-chromeless-input-container">
        <a href="/chinchang/hint.css/blame/master/README.md" class="header-search-scope no-underline">This repository</a>
      <input type="text"
        class="form-control header-search-input js-site-search-focus js-site-search-field is-clearable"
        data-hotkey="s"
        name="q"
        value=""
        placeholder="Search"
        aria-label="Search this repository"
        data-unscoped-placeholder="Search GitHub"
        data-scoped-placeholder="Search"
        autocapitalize="off">
        <input type="hidden" class="js-site-search-type-field" name="type" >
    </label>
</form></div>

          </div>

        <span class="d-inline-block">
            <div class="header-navlink px-0 py-2 m-0">
              <a class="text-bold text-white no-underline" href="/login?return_to=%2Fchinchang%2Fhint.css%2Fblame%2Fmaster%2FREADME.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
                <span class="text-gray">or</span>
                <a class="text-bold text-white no-underline" href="/join?source=header-repo" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
            </div>
        </span>
      </div>
    </div>
  </div>
</div>


  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">
</div>



  <div role="main">
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode">
    <div id="js-repo-pjax-container" data-pjax-container>
      



    <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav">
      <div class="container repohead-details-container">

        <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-eye" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/chinchang/hint.css/watchers"
     aria-label="219 users are watching this repository">
    219
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <svg aria-hidden="true" class="octicon octicon-star" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74z"/></svg>
    Star
  </a>

    <a class="social-count js-social-count" href="/chinchang/hint.css/stargazers"
      aria-label="7396 users starred this repository">
      7,396
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchinchang%2Fhint.css"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg aria-hidden="true" class="octicon octicon-repo-forked" height="16" version="1.1" viewBox="0 0 10 16" width="10"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/chinchang/hint.css/network" class="social-count"
       aria-label="724 users forked this repository">
      724
    </a>
  </li>
</ul>

        <h1 class="public ">
  <svg aria-hidden="true" class="octicon octicon-repo" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a href="/chinchang" class="url fn" rel="author">chinchang</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a href="/chinchang/hint.css" data-pjax="#js-repo-pjax-container">hint.css</a></strong>

</h1>

      </div>
      <div class="container">
        
<nav class="reponav js-repo-nav js-sidenav-container-pjax"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
     role="navigation"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css" class="js-selected-navigation-item selected reponav-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /chinchang/hint.css" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-code" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a href="/chinchang/hint.css/issues" class="js-selected-navigation-item reponav-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /chinchang/hint.css/issues" itemprop="url">
        <svg aria-hidden="true" class="octicon octicon-issue-opened" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">32</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a href="/chinchang/hint.css/pulls" class="js-selected-navigation-item reponav-item" data-hotkey="g p" data-selected-links="repo_pulls /chinchang/hint.css/pulls" itemprop="url">
      <svg aria-hidden="true" class="octicon octicon-git-pull-request" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">4</span>
      <meta itemprop="position" content="3">
</a>  </span>

    <a href="/chinchang/hint.css/projects" class="js-selected-navigation-item reponav-item" data-selected-links="repo_projects new_repo_project repo_project /chinchang/hint.css/projects">
      <svg aria-hidden="true" class="octicon octicon-project" height="16" version="1.1" viewBox="0 0 15 16" width="15"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      Projects
      <span class="Counter" >1</span>
</a>
    <a href="/chinchang/hint.css/wiki" class="js-selected-navigation-item reponav-item" data-hotkey="g w" data-selected-links="repo_wiki /chinchang/hint.css/wiki">
      <svg aria-hidden="true" class="octicon octicon-book" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M3 5h4v1H3V5zm0 3h4V7H3v1zm0 2h4V9H3v1zm11-5h-4v1h4V5zm0 2h-4v1h4V7zm0 2h-4v1h4V9zm2-6v9c0 .55-.45 1-1 1H9.5l-1 1-1-1H2c-.55 0-1-.45-1-1V3c0-.55.45-1 1-1h5.5l1 1 1-1H15c.55 0 1 .45 1 1zm-8 .5L7.5 3H2v9h6V3.5zm7-.5H9.5l-.5.5V12h6V3z"/></svg>
      Wiki
</a>

    <div class="reponav-dropdown js-menu-container">
      <button type="button" class="btn-link reponav-item reponav-dropdown js-menu-target " data-no-toggle aria-expanded="false" aria-haspopup="true">
        Insights
        <svg aria-hidden="true" class="octicon octicon-triangle-down v-align-middle text-gray" height="11" version="1.1" viewBox="0 0 12 16" width="8"><path fill-rule="evenodd" d="M0 5l6 6 6-6z"/></svg>
      </button>
      <div class="dropdown-menu-content js-menu-content">
        <div class="dropdown-menu dropdown-menu-sw">
          <a class="dropdown-item" href="/chinchang/hint.css/pulse" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-pulse" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M11.5 8L8.8 5.4 6.6 8.5 5.5 1.6 2.38 8H0v2h3.6l.9-1.8.9 5.4L9 8.5l1.6 1.5H14V8z"/></svg>
            Pulse
          </a>
          <a class="dropdown-item" href="/chinchang/hint.css/graphs" data-skip-pjax>
            <svg aria-hidden="true" class="octicon octicon-graph" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
            Graphs
          </a>
        </div>
      </div>
    </div>
</nav>

      </div>
    </div>

<div class="container new-discussion-timeline experiment-repo-nav">
  <div class="repository-content">

    

  <div class="wants-full-width-container"></div>

  <a href="/chinchang/hint.css/blame/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25/README.md" class="d-none js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
    <span class="css-truncate-target js-zeroclipboard-target"><span class="repo-root js-repo-root"><span class="js-path-segment"><a href="/chinchang/hint.css"><span>hint.css</span></a></span></span><span class="separator">/</span><strong class="final-path">README.md</strong></span>
    <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><svg aria-hidden="true" class="octicon octicon-clippy" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M2 13h4v1H2v-1zm5-6H2v1h5V7zm2 3V8l-3 3 3 3v-2h5v-2H9zM4.5 9H2v1h2.5V9zM2 12h2.5v-1H2v1zm9 1h1v2c-.02.28-.11.52-.3.7-.19.18-.42.28-.7.3H1c-.55 0-1-.45-1-1V4c0-.55.45-1 1-1h3c0-1.11.89-2 2-2 1.11 0 2 .89 2 2h3c.55 0 1 .45 1 1v5h-1V6H1v9h10v-2zM2 5h8c0-.55-.45-1-1-1H8c-.55 0-1-.45-1-1s-.45-1-1-1-1 .45-1 1-.45 1-1 1H3c-.55 0-1 .45-1 1z"/></svg></button>
  </div>

  <div class="line-age-legend">
    <span>Newer</span>
    <ol>
        <li class="heat" data-heat="1"></li>
        <li class="heat" data-heat="2"></li>
        <li class="heat" data-heat="3"></li>
        <li class="heat" data-heat="4"></li>
        <li class="heat" data-heat="5"></li>
        <li class="heat" data-heat="6"></li>
        <li class="heat" data-heat="7"></li>
        <li class="heat" data-heat="8"></li>
        <li class="heat" data-heat="9"></li>
        <li class="heat" data-heat="10"></li>
    </ol>
    <span>Older</span>
  </div>

  <div class="file">
    <div class="file-header">
      <div class="file-actions">
        <div class="BtnGroup">
          <a href="/chinchang/hint.css/raw/master/README.md" class="btn btn-sm BtnGroup-item" id="raw-url">Raw</a>
          <a href="/chinchang/hint.css/blob/master/README.md" class="btn btn-sm js-update-url-with-hash BtnGroup-item">Normal view</a>
          <a href="/chinchang/hint.css/commits/master/README.md" class="btn btn-sm BtnGroup-item" rel="nofollow">History</a>
        </div>
      </div>

  

      <div class="file-info">
        <svg aria-hidden="true" class="octicon octicon-file-text" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path d="M6 5H2V4h4v1zM2 8h7V7H2v1zm0 2h7V9H2v1zm0 2h7v-1H2v1zm10-7.5V14c0 .55-.45 1-1 1H1c-.55 0-1-.45-1-1V2c0-.55.45-1 1-1h7.5L12 4.5zM11 5L8 2H1v12h10V5z"/></svg>
        <span class="file-mode" title="File Mode">100644</span>
        <span class="file-info-divider"></span>
          124 lines (83 sloc)
          <span class="file-info-divider"></span>
        5.59 KB
      </div>
    </div>

    <div class="blob-wrapper">
      <table class="blame-container highlight data js-file-line-container tab-size" data-tab-size="8">
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-09-17T07:52:18Z">Sep 17, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1" class="message" data-pjax="true" title="update to commercial license">update to commercial license</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-mh"><span class="pl-mh">#</span><span class="pl-mh"> </span>Hint.css [![<span class="pl-e">npm version</span>](https://badge.fury.io/js/hint.css.svg)](https://badge.fury.io/js/hint.css) ![<span class="pl-e">downloads/month</span>](https://img.shields.io/npm/dm/hint.css.svg) [![<span class="pl-e">Join the chat at https://gitter.im/chinchang/hint.css</span>](https://badges.gitter.im/chinchang/hint.css.svg)](https://gitter.im/chinchang/hint.css?utm_source=badge&amp;utm_medium=badge&amp;utm_campaign=pr-badge&amp;utm_content=badge)</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-23T22:16:11Z">Mar 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/292d07f6997cfb7682872d1e6f85a243599c8bba" class="message" data-pjax="true" title="Minor fixes and additions.
- add IE10 to pseudo element transition supported list
- add &quot;Who&#39;s using it sections&quot;
- typos
- link the license
- Correct the lib description">Minor fixes and additions.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/0fc946c4450a132304e1f5b79cd01aa3df78b718/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC2"><span class="pl-mi">*A tooltip library in CSS for your lovely websites*</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC3"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-09-18T10:09:55Z">Sep 18, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/11461485cbf309cf5c414e57b560a542a95af906" class="message" data-pjax="true" title="Update README.md">Update README.md</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7c205d93ffafcb41c64f8a00277a8f9a9212406d/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC4">[<span class="pl-e">Demo</span>](https://kushagragour.in/lab/hint/) • [<span class="pl-e">Get started</span>](#get-started) • [<span class="pl-e">Who&#39;s using this?</span>](#whos-using-this) • [<span class="pl-e">Browser support</span>](#browser-support) • [<span class="pl-e">FAQs</span>](#faqs) • [<span class="pl-e">Contributing</span>](#contributing) • [<span class="pl-e">License</span>](#license)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-19T21:22:16Z">Feb 19, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/4ca85ede2dae8ebcc725f3ce7521004dfdbf4654" class="message" data-pjax="true" title="add blog link">add blog link</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/585d16b22952f433f0c827eaf7c9505e733f944a/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC5"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-06-05T09:22:08Z">Jun 5, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/00135c530a8380e2ea1101db60b45d27012d3dfa" class="message" data-pjax="true" title="readme: change desc.">readme: change desc.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/8fb8c989bf5cc1bdda6add1abcc17edd416e913f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-c1">`hint.css`</span> is written as a pure CSS resource using which you can create cool accessible tooltips for your web app. It does not rely on JavaScript but rather uses <span class="pl-mb">**aria-label**</span>/<span class="pl-mb">**data-* attribute**</span>, <span class="pl-mb">**pseudo elements**</span>, <span class="pl-mb">**content property**</span> and <span class="pl-mb">**CSS3 transitions**</span> to create the tooltips. Also it uses <span class="pl-mb">**BEM**</span> naming convention particularly for the modifiers.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC7"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Get Started</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC9"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-08-04T20:37:21Z">Aug 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/655232e4dd78c50c6d89b62592d7289628c563bd" class="message" data-pjax="true" title="Add ways to grab hint.css">Add ways to grab hint.css</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/fe05f50cbdab4ead69fa6410e33d114e77a9cd68/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC10">Get the library using one of the following ways:</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC11"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2015-11-20T23:48:47Z">Nov 20, 2015</time-ago></span>
                <a href="/EvanHahn" aria-label="EvanHahn" class="tooltipped tooltipped-e">
                  <img alt="@EvanHahn" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/777712?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/f19600edce2955868ad19b0fefb44eada2229ccd" class="message" data-pjax="true" title="The H in GitHub should be capitalized">The H in GitHub should be capitalized</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/49ba0f6faea3bc4866e2d10ab7dfa5cae4185160/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-v">1.</span> <span class="pl-mb">**GitHub**</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-08-04T20:37:21Z">Aug 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/655232e4dd78c50c6d89b62592d7289628c563bd" class="message" data-pjax="true" title="Add ways to grab hint.css">Add ways to grab hint.css</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/fe05f50cbdab4ead69fa6410e33d114e77a9cd68/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC13"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2014-07-06T11:45:03Z">Jul 6, 2014</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/b55d89c9af8f6b4a6faed3cd9ceb1f17c6f8ef3c" class="message" data-pjax="true" title="Add base build links.">Add base build links.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/851227989cbf18054cbd2e3d7a4a0179a9eab071/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC14"> Full build</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="4">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-08-04T20:37:21Z">Aug 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/655232e4dd78c50c6d89b62592d7289628c563bd" class="message" data-pjax="true" title="Add ways to grab hint.css">Add ways to grab hint.css</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="4">
                  <a href="/chinchang/hint.css/blame/fe05f50cbdab4ead69fa6410e33d114e77a9cd68/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC15"> <span class="pl-v">-</span> [unminified] : https://raw.github.com/chinchang/hint.css/master/hint.css</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC16"> <span class="pl-v">-</span> [minified] : https://raw.github.com/chinchang/hint.css/master/hint.min.css</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC17"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="5">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2014-07-06T11:45:03Z">Jul 6, 2014</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/b55d89c9af8f6b4a6faed3cd9ceb1f17c6f8ef3c" class="message" data-pjax="true" title="Add base build links.">Add base build links.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="5">
                  <a href="/chinchang/hint.css/blame/851227989cbf18054cbd2e3d7a4a0179a9eab071/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC18"> Base build <span class="pl-mi">*(Does not include color themes and fancy effects)*</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC19"> <span class="pl-v">-</span> [unminified] : https://raw.github.com/chinchang/hint.css/master/hint.base.css</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC20"> <span class="pl-v">-</span> [minified] : https://raw.github.com/chinchang/hint.css/master/hint.base.min.css</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC21"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-05-21T09:04:01Z">May 21, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56" class="message" data-pjax="true" title="Add docs to use aria-label attribute">Add docs to use aria-label attribute</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bea5c8df1df14a52e2277e5353ae3233ffa0077f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC22"><span class="pl-v">2.</span> <span class="pl-mb">**Bower**</span> : <span class="pl-c1">`bower install hint.css`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-08-04T20:37:21Z">Aug 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/655232e4dd78c50c6d89b62592d7289628c563bd" class="message" data-pjax="true" title="Add ways to grab hint.css">Add ways to grab hint.css</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/fe05f50cbdab4ead69fa6410e33d114e77a9cd68/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC23"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-05-21T09:04:01Z">May 21, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56" class="message" data-pjax="true" title="Add docs to use aria-label attribute">Add docs to use aria-label attribute</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bea5c8df1df14a52e2277e5353ae3233ffa0077f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC24"><span class="pl-v">3.</span> <span class="pl-mb">**npm**</span>: <span class="pl-c1">`npm install --save hint.css`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-13T10:20:22Z">Jan 13, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/9e4203e35c1fdbcbc8c157df0765c0cfd4fb506a" class="message" data-pjax="true" title="docs(readme): add link to cdnjs hosted version">docs(readme): add link to cdnjs hosted version</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/d960fb98005881604436192d4dc63f70cde0ff65/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC25"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-05-21T09:34:30Z">May 21, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7ea96ff38cc0607f063395ac72c9b3af5e480b83" class="message" data-pjax="true" title="typo">typo</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/68d7ae0b3e5489475f059e55f9356dc4acb8e43b/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC26"><span class="pl-v">4.</span> <span class="pl-mb">**CDN**</span>: [<span class="pl-e">http://www.jsdelivr.com/#!hint.css</span>](http://www.jsdelivr.com/#!hint.css) or [<span class="pl-e">https://cdnjs.com/libraries/hint.css</span>](https://cdnjs.com/libraries/hint.css)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-08-04T20:37:21Z">Aug 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/655232e4dd78c50c6d89b62592d7289628c563bd" class="message" data-pjax="true" title="Add ways to grab hint.css">Add ways to grab hint.css</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/fe05f50cbdab4ead69fa6410e33d114e77a9cd68/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC27"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-13T11:17:45Z">Jan 13, 2016</time-ago></span>
                <a href="/pra85" aria-label="pra85" class="tooltipped tooltipped-e">
                  <img alt="@pra85" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/829526?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/ac2b41400f9c19a0d38a7f3e977d03637c8bf0bb" class="message" data-pjax="true" title="docs(readme): change sentence structure and words used">docs(readme): change sentence structure and words used</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/d960fb98005881604436192d4dc63f70cde0ff65/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC28">Now include the library in the <span class="pl-c1">``HEAD``</span> tag of your page:</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC29"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC30"><span class="pl-c1">```html</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC31">&lt;<span class="pl-ent">link</span> <span class="pl-e">rel</span>=<span class="pl-s"><span class="pl-pds">&quot;</span>stylesheet<span class="pl-pds">&quot;</span></span> <span class="pl-e">href</span>=<span class="pl-s"><span class="pl-pds">&quot;</span>hint.css<span class="pl-pds">&quot;</span></span>&gt;&lt;/<span class="pl-ent">link</span>&gt;</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC32"><span class="pl-c1">```</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="7">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="7">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC33">or</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC34"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC35"><span class="pl-c1">```html</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC36">&lt;<span class="pl-ent">link</span> <span class="pl-e">rel</span>=<span class="pl-s"><span class="pl-pds">&quot;</span>stylesheet<span class="pl-pds">&quot;</span></span> <span class="pl-e">href</span>=<span class="pl-s"><span class="pl-pds">&quot;</span>hint.min.css<span class="pl-pds">&quot;</span></span>&gt;&lt;/<span class="pl-ent">link</span>&gt;</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC37"><span class="pl-c1">```</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC38"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-05-21T09:04:01Z">May 21, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56" class="message" data-pjax="true" title="Add docs to use aria-label attribute">Add docs to use aria-label attribute</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bea5c8df1df14a52e2277e5353ae3233ffa0077f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC39">Now, all you need to do is give your element any position class and tooltip text using the <span class="pl-c1">`aria-label`</span> attribute.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-05-21T09:34:30Z">May 21, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/7ea96ff38cc0607f063395ac72c9b3af5e480b83" class="message" data-pjax="true" title="typo">typo</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/68d7ae0b3e5489475f059e55f9356dc4acb8e43b/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC40">Note, if you don&#39;t want to use <span class="pl-c1">`aria-label`</span> attribute, you can also specify the tooltip text using the <span class="pl-c1">`data-hint`</span> attribute, but its recommended to use <span class="pl-c1">`aria-label`</span> in support of accessibility. [<span class="pl-e">Read more about aria-label</span>](https://webaccessibility.withgoogle.com/unit?unit=6&amp;lesson=10).</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="4">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="4">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC41"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC42"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC43"><span class="pl-c1">```html</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-05-21T09:04:01Z">May 21, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/9317acf7abe28b2b7a2b573c3ed5cd456f5f3d56" class="message" data-pjax="true" title="Add docs to use aria-label attribute">Add docs to use aria-label attribute</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bea5c8df1df14a52e2277e5353ae3233ffa0077f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC44">Hello Sir, &lt;<span class="pl-ent">span</span> <span class="pl-e">class</span>=<span class="pl-s"><span class="pl-pds">&quot;</span>hint--bottom<span class="pl-pds">&quot;</span></span> <span class="pl-e">aria-label</span>=<span class="pl-s"><span class="pl-pds">&quot;</span>Thank you!<span class="pl-pds">&quot;</span></span>&gt;hover me.&lt;/<span class="pl-ent">span</span>&gt;</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="4">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="4">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC45"><span class="pl-c1">```</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC46"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC47">Use it with other available modifiers in various combinations. Available modifiers:</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-03-07T21:02:03Z">Mar 7, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/691fd4f267e9328511f7b3a0b1bea8830e5a732d" class="message" data-pjax="true" title="fix readme.">fix readme.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/8409f3a1e17eb2c13461ba96572ac340c89df560/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC48"><span class="pl-v">-</span> <span class="pl-mi">*Colors*</span> - <span class="pl-c1">`hint--error`</span>, <span class="pl-c1">`hint--info`</span>, <span class="pl-c1">`hint--warning`</span>, <span class="pl-c1">`hint--success`</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC49"><span class="pl-v">-</span> <span class="pl-mi">*Sizes*</span> - <span class="pl-c1">`hint--small`</span>, <span class="pl-c1">`hint--medium`</span>, <span class="pl-c1">`hint--large`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC50"><span class="pl-v">-</span> <span class="pl-c1">`hint--always`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-20T20:33:34Z">Feb 20, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/c68069999783b67ed003773cd0b650b125b0b6e7" class="message" data-pjax="true" title="add rounded to modifier list">add rounded to modifier list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/4ca85ede2dae8ebcc725f3ce7521004dfdbf4654/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC51"><span class="pl-v">-</span> <span class="pl-c1">`hint--rounded`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2014-05-18T13:24:50Z">May 18, 2014</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/4d9b69ac6d70bd32c5123300fbe6bfd463625d26" class="message" data-pjax="true" title="Add hint--no-animate in modifier listing.">Add hint--no-animate in modifier listing.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/0785e4eceb9b8aca03cd6f07fe0a938612de0d45/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC52"><span class="pl-v">-</span> <span class="pl-c1">`hint--no-animate`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-08-04T20:44:01Z">Aug 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/f9aa351a384fbf1be01cfb1e442636be7c8e217c" class="message" data-pjax="true" title="add hint--bounce to modifier list">add hint--bounce to modifier list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/3ccdc6a3ff9b43d9200236c56b261c812dbc5d89/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC53"><span class="pl-v">-</span> <span class="pl-c1">`hint--bounce`</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC54"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="5">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-25T10:13:37Z">Jan 25, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/00825ed7a38ed41793f57aa8590455cfa1143264" class="message" data-pjax="true" title="fix readme.">fix readme.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="5">
                  <a href="/chinchang/hint.css/blame/475d475e7c1b8d499d3196f1299c3a81c2c7d140/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC55"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Upgrading from v1.x</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC56"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC57">If you are already using v1.x, you may need to tweak certain position classes because of the way tooltips are positioned in v2.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC58"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-11-21T09:16:22Z">Nov 21, 2013</time-ago></span>
                <a href="/katgironpe" aria-label="katgironpe" class="tooltipped tooltipped-e">
                  <img alt="@katgironpe" class="avatar blame-commit-avatar" height="16" src="https://avatars1.githubusercontent.com/u/50656?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d3be84c7f5cf17f650ca46ccee20624cdd570e5a" class="message" data-pjax="true" title="Allow changing &#39;hint--&#39; prefix to something else.
fixes chinchang/hint.css/#12">Allow changing 'hint--' prefix to something else.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/029170a7dbece6d2688e0df54d256e53c01f68ed/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC59"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Changing the prefix for class names</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC60"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-11-22T20:11:10Z">Nov 22, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/398dd42d43a39de9593dc256ae409c041cdfedc2" class="message" data-pjax="true" title="- Add !default to `prefix` variable and fix its comment.
- Tweak readme doc for prefix change.">- Add !default to `prefix` variable and fix its comment.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/e215c3e8fa41cc922c33b834e1632c6ff8113edb/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC61">Don&#39;t like BEM naming (<span class="pl-c1">`hint--`</span>) or want to use your own prefix for the class names?</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-11-22T20:15:05Z">Nov 22, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/ee05547a2635ba6352fe67402ed654538dc81f4f" class="message" data-pjax="true" title="Add newline.">Add newline.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/398dd42d43a39de9593dc256ae409c041cdfedc2/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC62"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-02-04T10:38:27Z">Feb 4, 2016</time-ago></span>
                <a href="/CupOfTea696" aria-label="CupOfTea696" class="tooltipped tooltipped-e">
                  <img alt="@CupOfTea696" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/7327050?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/c502cd7ebbfd24bbe09327ab07fd6aa9eff70f17" class="message" data-pjax="true" title="camelCase variables">camelCase variables</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/c815e638e2e086cda8a0085d3cb7eb98f0d6e325/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC63">Simply update <span class="pl-c1">`src/hint-variables.scss`</span> and change the <span class="pl-c1">`$hintPrefix`</span> variable.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-11-21T09:16:22Z">Nov 21, 2013</time-ago></span>
                <a href="/katgironpe" aria-label="katgironpe" class="tooltipped tooltipped-e">
                  <img alt="@katgironpe" class="avatar blame-commit-avatar" height="16" src="https://avatars1.githubusercontent.com/u/50656?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d3be84c7f5cf17f650ca46ccee20624cdd570e5a" class="message" data-pjax="true" title="Allow changing &#39;hint--&#39; prefix to something else.
fixes chinchang/hint.css/#12">Allow changing 'hint--' prefix to something else.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/029170a7dbece6d2688e0df54d256e53c01f68ed/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC64">To generate the css file, please read the [<span class="pl-e">contributing page</span>](./CONTRIBUTING.md).</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC65"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-23T22:16:11Z">Mar 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/292d07f6997cfb7682872d1e6f85a243599c8bba" class="message" data-pjax="true" title="Minor fixes and additions.
- add IE10 to pseudo element transition supported list
- add &quot;Who&#39;s using it sections&quot;
- typos
- link the license
- Correct the lib description">Minor fixes and additions.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/0fc946c4450a132304e1f5b79cd01aa3df78b718/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC66"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Who&#39;s Using This?</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2015-12-03T18:14:44Z">Dec 3, 2015</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/c320243611b8280369f3b0b5f2ab12bf0836cce4" class="message" data-pjax="true" title="fix webflow name in user list">fix webflow name in user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/806359e13841813c0cfd6bca38a533422291a12c/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC67"><span class="pl-v">-</span> [<span class="pl-e">Webflow Playground</span>](http://playground.webflow.com/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2015-12-29T06:14:00Z">Dec 29, 2015</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d960fb98005881604436192d4dc63f70cde0ff65" class="message" data-pjax="true" title="add usepanda.com to user list">add usepanda.com to user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/a289af46e9d4cdb42f283fb1853e815cf2231b6f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC68"><span class="pl-v">-</span> [<span class="pl-e">Panda chrome app</span>](http://usepanda.com/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-08-15T19:56:54Z">Aug 15, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1" class="message" data-pjax="true" title="add fiverr">add fiverr</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/b94fcfd5dc358df8581c9fadd3de74043f23f56c/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC69"><span class="pl-v">-</span> [<span class="pl-e">Fiverr</span>](https://www.fiverr.com/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2017-01-16T20:26:30Z">Jan 16, 2017</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/8043580a884d1bfbc232949e83b92595741caf05" class="message" data-pjax="true" title="update user list">update user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/842c8d5f3da65142425e3489d55a01539669cf65/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC70"><span class="pl-v">-</span> [<span class="pl-e">Stackshare</span>](http://stackshare.io/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2017-06-26T11:42:44Z">Jun 26, 2017</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25" class="message" data-pjax="true" title="add web maker to user list">add web maker to user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/5bf38931dfb6995c2e7c70551c617726f789cfb3/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="1"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC71"><span class="pl-v">-</span> [<span class="pl-e">Siftery</span>](https://siftery.com/)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="1"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC72"><span class="pl-v">-</span> [<span class="pl-e">LessPass</span>](https://lesspass.com/#/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-09-17T19:36:38Z">Sep 17, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/b11c1745cb83c16df839f6878a9474dca5ac401a" class="message" data-pjax="true" title="add tridiv to hint user list">add tridiv to hint user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/8b4f645798c465a0c6dbcde193019351ae916a83/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="9"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC73"><span class="pl-v">-</span> [<span class="pl-e">Tridiv</span>](http://tridiv.com/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2017-01-16T20:26:30Z">Jan 16, 2017</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/8043580a884d1bfbc232949e83b92595741caf05" class="message" data-pjax="true" title="update user list">update user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/842c8d5f3da65142425e3489d55a01539669cf65/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC74"><span class="pl-v">-</span> [<span class="pl-e">Alm - TypeScript IDE</span>](http://alm.tools/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-03-26T21:06:38Z">Mar 26, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/9ede1d4da020ef7e85356a4d46862db45142ac6a" class="message" data-pjax="true" title="add prototyp to user list">add prototyp to user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/d3b904418d7494efa0dadbd7112940c29f36d69e/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC75"><span class="pl-v">-</span> [<span class="pl-e">Prototyp</span>](http://prototyp.in/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2014-05-17T18:24:07Z">May 17, 2014</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/f2597c437e1f5a8f9c423f7b8e81f4a12a6cd43a" class="message" data-pjax="true" title="Add tradus.com to user list.">Add tradus.com to user list.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/fa7adeaa93ec981f73319c33c0ea88fc93b0a93f/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="7"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC76"><span class="pl-v">-</span> [<span class="pl-e">Tradus</span>](http://tradus.com/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2017-06-26T11:42:44Z">Jun 26, 2017</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/70f111e7c437447ca1b9ed40efa9fa8f82c7ee25" class="message" data-pjax="true" title="add web maker to user list">add web maker to user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/5bf38931dfb6995c2e7c70551c617726f789cfb3/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="1"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC77"><span class="pl-v">-</span> [<span class="pl-e">Web Maker</span>](https://webmakerapp.com)</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="1"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC78"><span class="pl-v">-</span> [<span class="pl-e">Tolks</span>](https://tolks.io)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-24T19:29:03Z">Jan 24, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/a05e8dca95fbb9a3b57739d5769370803d363104" class="message" data-pjax="true" title="add more users">add more users</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/207733c1997802872c15552b019cd4b3dbc66323/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC79"><span class="pl-v">-</span> [<span class="pl-e">Formspree</span>](http://formspree.io/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2015-12-28T21:00:16Z">Dec 28, 2015</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/332fb80b6f35ed2589dec1fbe77621feaeef44bc" class="message" data-pjax="true" title="Add codemagic to user list

codeMagic is a tool by @varemenos">Add codemagic to user list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/c320243611b8280369f3b0b5f2ab12bf0836cce4/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC80"><span class="pl-v">-</span> [<span class="pl-e">codeMagic</span>](http://codemagic.gr/)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-23T22:16:11Z">Mar 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/292d07f6997cfb7682872d1e6f85a243599c8bba" class="message" data-pjax="true" title="Minor fixes and additions.
- add IE10 to pseudo element transition supported list
- add &quot;Who&#39;s using it sections&quot;
- typos
- link the license
- Correct the lib description">Minor fixes and additions.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/0fc946c4450a132304e1f5b79cd01aa3df78b718/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC81"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-03-07T21:02:03Z">Mar 7, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/691fd4f267e9328511f7b3a0b1bea8830e5a732d" class="message" data-pjax="true" title="fix readme.">fix readme.</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/8409f3a1e17eb2c13461ba96572ac340c89df560/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC82">Are you using <span class="pl-mb">**hint.css**</span> in your awesome project too? Just tweet it out to [<span class="pl-e">@hint_css</span>](https://twitter.com/hint_css) or let us know on the [<span class="pl-e">mailing list</span>](mailto:hintcss@googlegroups.com).</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC83"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="11">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-04-06T08:48:04Z">Apr 6, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/0b2461b5c679f34da76cddce2f4cb785a8257e84" class="message" data-pjax="true" title="[docs] add browser support list and current version to title">[docs] add browser support list and current version to title</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="11">
                  <a href="/chinchang/hint.css/blame/e7331ad21b445bcfb8adaf84ab5bee772c1527d3/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC84"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Browser Support</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC85"><span class="pl-mb">**hint.css**</span> works on all latest browsers, though the transition effect is supported only on IE10+, Chrome 26+ and FF4+ at present.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC86"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC87"><span class="pl-v">-</span> Chrome - basic + transition effects</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC88"><span class="pl-v">-</span> Firefox - basic + transition effects</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC89"><span class="pl-v">-</span> Opera - basic</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC90"><span class="pl-v">-</span> Safari - basic</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC91"><span class="pl-v">-</span> IE 10+ - basic + transition effects</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC92"><span class="pl-v">-</span> IE 8 &amp; 9 - basic</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC93"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="4">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-08-01T18:16:50Z">Aug 1, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/b94fcfd5dc358df8581c9fadd3de74043f23f56c" class="message" data-pjax="true" title="add faq wiki link">add faq wiki link</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="4">
                  <a href="/chinchang/hint.css/blame/8b63bde325f4f77d4eaad7cf5ba1c5542704a0de/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC94"><span class="pl-mh"><span class="pl-mh">###</span><span class="pl-mh"> </span>FAQs</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC95"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="3"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC96">Checkout the [<span class="pl-e">FAQ Wiki</span>](https://github.com/chinchang/hint.css/wiki/Frequently-Asked-Questions) for some common gotchas to be aware of while using <span class="pl-mb">**hint.css**</span>.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-04-06T08:48:04Z">Apr 6, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/0b2461b5c679f34da76cddce2f4cb785a8257e84" class="message" data-pjax="true" title="[docs] add browser support list and current version to title">[docs] add browser support list and current version to title</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/e7331ad21b445bcfb8adaf84ab5bee772c1527d3/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC97"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:13:38Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/d2d4eaf69a0347f8ddab061ca34a8cfc9578b0d1" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/36919a19ec1f7139ad62fe5bd3dd491b358d7d15/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC98"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Contributing</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="5">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T10:33:08Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/bd8205929799207d66f91cbf34449395cd0a4309" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="5">
                  <a href="/chinchang/hint.css/blame/68e6d8f9797468f0baa645d21934402384f2e92d/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC99"><span class="pl-c1">`hint.css`</span> is developed in SASS and the source files can be found in the <span class="pl-c1">`src/`</span> directory.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC100"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC101">If you would like to create more types of tooltips/ fix bugs/ enhance the library etc. you are more than welcome to submit your pull requests.</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC102"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-23T15:22:27Z">Feb 23, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/3a922501f91b7df6cc877c15aa18d619e701d8f2" class="message" data-pjax="true" title="add contributing link in README and make correction in Contributing">add contributing link in README and make correction in Contributing</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/325a714c2a22cc9fcba77d0c3f3652eeef861d07/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC103">[<span class="pl-e">Read more on contributing</span>](./CONTRIBUTING.md).</td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC104"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="3">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-26T18:57:05Z">Jan 26, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/cdce53203f99d0e685c64fbab905906a60b3ba1f" class="message" data-pjax="true" title="tweak changelog section">tweak changelog section</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="3">
                  <a href="/chinchang/hint.css/blame/0a1f0d8ce8ab23f17658019f97b59bda12691e08/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC105"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Changelog &amp; Updates</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC106">See the [<span class="pl-e">Changelog</span>](https://github.com/chinchang/hint.css/wiki/Changelog).</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC107"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-26T18:57:05Z">Jan 26, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/cdce53203f99d0e685c64fbab905906a60b3ba1f" class="message" data-pjax="true" title="tweak changelog section">tweak changelog section</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/0a1f0d8ce8ab23f17658019f97b59bda12691e08/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC108">To catch all updates and discussion, join the mailing list: [<span class="pl-e">**hintcss@googlegroups.com**</span>](https://groups.google.com/forum/?fromgroups=#!forum/hintcss).</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-03T19:49:10Z">Mar 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/2cbaf5b23bf226e36129e2dd521b1e672fe6b498" class="message" data-pjax="true" title="v1.2.0 [Hotfix] add mailing list address">v1.2.0 [Hotfix] add mailing list address</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/453611b2ae04974530f4dc95cb6a50d970f33331/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC109"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-01-26T18:57:05Z">Jan 26, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/cdce53203f99d0e685c64fbab905906a60b3ba1f" class="message" data-pjax="true" title="tweak changelog section">tweak changelog section</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/0a1f0d8ce8ab23f17658019f97b59bda12691e08/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="4"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC110">Or follow on twitter: [<span class="pl-e">**@hint_css**</span>](https://twitter.com/hint_css)</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-03-03T19:49:10Z">Mar 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/2cbaf5b23bf226e36129e2dd521b1e672fe6b498" class="message" data-pjax="true" title="v1.2.0 [Hotfix] add mailing list address">v1.2.0 [Hotfix] add mailing list address</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/453611b2ae04974530f4dc95cb6a50d970f33331/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC111"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC112"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>License</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="4">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-09-17T07:52:18Z">Sep 17, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1" class="message" data-pjax="true" title="update to commercial license">update to commercial license</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="4">
                  <a href="/chinchang/hint.css/blame/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC113"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC114"><span class="pl-mh"><span class="pl-mh">###</span><span class="pl-mh"> </span>Commercial License</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC115"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-09-18T10:09:55Z">Sep 18, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/11461485cbf309cf5c414e57b560a542a95af906" class="message" data-pjax="true" title="Update README.md">Update README.md</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/7c205d93ffafcb41c64f8a00277a8f9a9212406d/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC116">If you want to use Hint.css for business, commercial sites, themes, projects, and applications, the Commercial license is the appropriate license. With this option, your source code is kept proprietary. Purchase a Hint.css Commercial License at https://kushagragour.in/lab/hint/#commercial</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="5">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2016-09-17T07:52:18Z">Sep 17, 2016</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/af4af713dbd1808e6f9ce70fb3249bcfc2ea01b1" class="message" data-pjax="true" title="update to commercial license">update to commercial license</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="5">
                  <a href="/chinchang/hint.css/blame/e3150685b3a7e2e8f8a08b3a65f28189c5980dc1/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC117"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC118"><span class="pl-mh"><span class="pl-mh">###</span><span class="pl-mh"> </span>Open-source License</span></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC119"></td>
              </tr>
              <tr class="blame-line">
                <td class="line-age heat" data-heat="2"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC120">Hint.css is free for personal use under the GNU AGPLv3.</td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2012-12-30T20:56:02Z">Dec 30, 2012</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/440dc8cc15e260101bc5d2baad0bda89d37a5098" class="message" data-pjax="true" title="create project file structure">create project file structure</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/bad16618b8c7664734815f24cf24ad1bc0bcb1fd/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC121"></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-02-03T11:03:13Z">Feb 3, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/5f4ef44dffd94722ea555d8409464918bc5f7a70" class="message" data-pjax="true" title="update readme">update readme</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/25992673e00078ae733b5cb5dacdbf7854c5d5dc/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC122"><span class="pl-mh"><span class="pl-mh">##</span><span class="pl-mh"> </span>Credits</span></td>
              </tr>
          </tbody>
          <tbody class="blame-hunk">
            <tr class="blame-commit">
              <td class="blame-commit-info" rowspan="2">
                <span class="blame-commit-date text-gray-light"><time-ago datetime="2013-06-04T19:10:55Z">Jun 4, 2013</time-ago></span>
                <a href="/chinchang" aria-label="chinchang" class="tooltipped tooltipped-e">
                  <img alt="@chinchang" class="avatar blame-commit-avatar" height="16" src="https://avatars3.githubusercontent.com/u/379918?v=4&amp;s=32" width="16" />
</a>                <span class="blame-commit-title">
                    <a href="/chinchang/hint.css/commit/a2f2f6973dcda51ac6e20ed21338a8e763d35e81" class="message" data-pjax="true" title="Add Inkpen in &#39;WHos using&#39; list">Add Inkpen in 'WHos using' list</a>
                </span>
              </td>
              <td class="blob-reblame" rowspan="2">
                  <a href="/chinchang/hint.css/blame/f6f72b5cc441a5382da21a1037ec55e3651946cb/README.md"
                    aria-label="View blame prior to this change" class="reblame-link tooltipped tooltipped-w">
                    <svg aria-hidden="true" class="octicon octicon-versions" height="16" version="1.1" viewBox="0 0 14 16" width="14"><path fill-rule="evenodd" d="M13 3H7c-.55 0-1 .45-1 1v8c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zm-1 8H8V5h4v6zM4 4h1v1H4v6h1v1H4c-.55 0-1-.45-1-1V5c0-.55.45-1 1-1zM1 5h1v1H1v4h1v1H1c-.55 0-1-.45-1-1V6c0-.55.45-1 1-1z"/></svg>
                  </a>
              </td>
            </tr>

              <tr class="blame-line">
                <td class="line-age heat" data-heat="10"></td>
                <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
                <td class="blob-code blob-code-inner js-file-line" id="LC123">This doesn&#39;t make use of a lot of BEM methodology but big thanks to [<span class="pl-e">@csswizardry</span>](https://twitter.com/csswizardry), [<span class="pl-e">@necolas</span>](https://twitter.com/necolas) for their awesome articles on BEM and to [<span class="pl-e">@joshnh</span>](https://twitter.com/_joshnh) through whose work I came to know about it :)</td>
              </tr>
          </tbody>
      </table>
    </div>

  </div>


  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

      
<div class="container-lg site-footer-container">
  <div class="site-footer " role="contentinfo">
    <ul class="site-footer-links float-right">
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact GitHub</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage" class="site-footer-mark" title="GitHub">
      <svg aria-hidden="true" class="octicon octicon-mark-github" height="24" version="1.1" viewBox="0 0 16 16" width="24"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2017 <span title="0.12677s from unicorn-1253541411-n553q">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a href="https://help.github.com" data-ga-click="Footer, go to help, text:help">Help</a></li>
    </ul>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <button type="button" class="flash-close js-flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
    You can't perform that action at this time.
  </div>


    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/compat-91f98c37fc84eac24836eec2567e9912742094369a04c4eba6e3cd1fa18902d9.js"></script>
    <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-fb7732750125d3d783cd735f5f1ecddc0fab988ecd5bd8ce63c326337b7c4de6.js"></script>
    
    <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github-da8e77af323b7cf0c46c7ce4e7a65719fb641271a5d4d8cc9010b77f135085d5.js"></script>
    
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg aria-hidden="true" class="octicon octicon-alert" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M8.865 1.52c-.18-.31-.51-.5-.87-.5s-.69.19-.87.5L.275 13.5c-.18.31-.18.69 0 1 .19.31.52.5.87.5h13.7c.36 0 .69-.19.86-.5.17-.31.18-.69.01-1L8.865 1.52zM8.995 13h-2v-2h2v2zm0-3h-2V6h2v4z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg aria-hidden="true" class="octicon octicon-x" height="16" version="1.1" viewBox="0 0 12 16" width="12"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48z"/></svg>
    </button>
  </div>
</div>


  </body>
</html>

